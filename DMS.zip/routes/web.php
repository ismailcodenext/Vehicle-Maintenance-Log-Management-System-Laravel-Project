<?php

use App\Http\Controllers\PCController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TestController;


// ------------Controller Work By  start--------------------
use App\Http\Controllers\UserController;
use App\Http\Controllers\DoctorController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\TestCategoryController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\ExpensesCategoryController;
use App\Http\Controllers\ExpensesController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ReportController;

// ------------Controller Work By  End--------------------


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
// Open Dashboard API Route
Route::view('/', 'pages.front-end-page.auth.login-page');

/// Dashboard all Api
Route::get("/dashboard-all-calculation", [DashboardController::class, 'DashboardAllCalculation'])->middleware('auth:sanctum');

/// Doctor all Api
Route::get("/list-doctor", [DoctorController::class, 'DoctorList'])->name('doctor.list')->middleware('auth:sanctum');
Route::post("/create-doctor", [DoctorController::class, 'DoctorCreate'])->middleware('auth:sanctum');
Route::post("/doctor-by-id", [DoctorController::class, 'DoctorByUpdate'])->middleware('auth:sanctum');
Route::post("/update-Doctor", [DoctorController::class, 'DoctorUpdate'])->middleware('auth:sanctum');
Route::post("/delete-Doctor", [DoctorController::class, 'DoctorDelete'])->middleware('auth:sanctum');

/// Doctor all Api
Route::get("/list-pc", [PCController::class, 'PCList'])->middleware('auth:sanctum');
Route::post("/create-pc", [PCController::class, 'PCCreate'])->middleware('auth:sanctum');
Route::post("/pc-by-id", [PCController::class, 'PCByID'])->middleware('auth:sanctum');
Route::post("/update-pc", [PCController::class, 'PCUpdate'])->middleware('auth:sanctum');
Route::post("/delete-pc", [PCController::class, 'PCDelete'])->middleware('auth:sanctum');

/// Invoice all Api
Route::get("/invoice-report", [InvoiceController::class, 'InvoiceReportList'])->middleware('auth:sanctum');
Route::get("/all-invoice-report", [InvoiceController::class, 'AllInvoiceReportList'])->middleware('auth:sanctum');
Route::post("/create-invoice", [InvoiceController::class, 'CreateInvoice'])->middleware('auth:sanctum');
Route::post("/create-old-patient-invoice", [InvoiceController::class, 'CreateOldPatientInvoice'])->middleware('auth:sanctum');
Route::get('/invoices-by-patient/{patient_id}', [InvoiceController::class, 'GetInvoicesByPatient'])->middleware('auth:sanctum');
Route::get('/invoices-by-pc/{pc_id}', [InvoiceController::class, 'GetInvoicesByPC'])->middleware('auth:sanctum');
Route::get("/all-due-invoice-report", [InvoiceController::class, 'AllDueInvoiceReportList'])->middleware('auth:sanctum');
Route::post("/pay-due", [InvoiceController::class, 'PayDue'])->middleware('auth:sanctum');
Route::post("/invoice-by-id", [InvoiceController::class, 'InvoiceByID'])->middleware('auth:sanctum');
Route::post("/delete-invoice", [InvoiceController::class, 'DeleteInvoice'])->middleware('auth:sanctum');
// ----------------------------Dashboard Route Work Ismail Start-----------------------------------------------------

Route::view('/patient-page', 'pages.back-end-page.patient-page');
Route::view('/invoicePage', 'pages.back-end-page.invoice-page');
Route::view('/oldPatientsPage', 'pages.back-end-page.old-paitent-invoice-page');
Route::view('/pcPage', 'pages.back-end-page.pc-page');
Route::view('/invoicePrint', 'pages.back-end-page.invoice-print-page');


// ----------------------------Dashboard Route Work Ismail End-----------------------------------------------------



// ----------------------------Dashboard Route Work Robiul Start-----------------------------------------------------

// front-page User API Route Start

Route::view('/diagnostic-login-page', 'pages.front-end-page.auth.login-page')->name('login');
Route::view('/registration', 'pages.front-end-page.auth.registration-page');
Route::view('/sendOtp', 'pages.front-end-page.auth.send-otp-page');
Route::view('/verifyOtp', 'pages.front-end-page.auth.verify-otp-page');
Route::view('/resetPassword', 'pages.front-end-page.auth.reset-pass-page');
Route::view('/userProfile', 'pages.dashboard.profile-page');


// User Web API Routes
// Route::post('/user-registration', [UserController::class, 'UserRegistration'])->middleware('auth:sanctum');
Route::post('/user-registration', [UserController::class, 'UserRegistration']);
Route::post('/user-login', [UserController::class, 'UserLogin']);
Route::get('/user-profile', [UserController::class, 'UserProfile'])->middleware('auth:sanctum');
Route::get('/userlogout', [UserController::class, 'UserLogout'])->middleware('auth:sanctum');
Route::post('/user-update', [UserController::class, 'UpdateProfile'])->middleware('auth:sanctum');
Route::post('/send-otp', [UserController::class, 'SendOTPCode']);
Route::post('/verify-otp', [UserController::class, 'VerifyOTP']);
Route::post('/reset-password', [UserController::class, 'ResetPassword'])->middleware('auth:sanctum');

// front-page API Route End

// Dashboard API Route start
// Route::view('/dashboardSummary','pages.back-end-page.dashboard-page');
Route::view('/dashboardSummary', 'pages.dashboard.dashboard-page');

//  Page View API Route
Route::view('/doctorpage', 'pages.back-end-page.doctor-page');
Route::view('/testCategoryPage', 'pages.back-end-page.test-categorie-page');
Route::view('/testPage', 'pages.back-end-page.test-page');
Route::view('/patientsPage', 'pages.back-end-page.patient-page');
// Route::view('/oldPatientsPage', 'pages.back-end-page.old-paitent-page');
Route::view('/expensesCategoriePage', 'pages.back-end-page.expenses-categorie-page');
Route::view('/expensesPage', 'pages.back-end-page.expenses-page');
Route::view('/dateWiseExpensesPage', 'pages.back-end-page.date-wise-expenses-page');
Route::view('/dateWiseInvoiceReportPage', 'pages.back-end-page.date-wise-invoice-report-page');
Route::view('/allInvoiceReportPage', 'pages.back-end-page.all-invoice-report-page');
Route::view('/patientWiseInvoiceReportPage', 'pages.back-end-page.patient-wise-invoice-report-page');
Route::view('/allDueInvoiceReportPage', 'pages.back-end-page.all-due-invoice-report-page');
Route::view('/PermissionPage', 'pages.back-end-page.permission-page');
Route::view('/RolesPage', 'pages.back-end-page.roles-page');
Route::view('/RoleInPermissionPage', 'pages.back-end-page.role-in-permission-page');
Route::view('/RoleInPermissionPageTest', 'pages.back-end-page.role-in-permission-test-page');
Route::view('/PCWiseInvoiceReportPage', 'pages.back-end-page.pc-wise-invoice-report-page');
Route::view('/AllTestReportPage', 'pages.back-end-page.all-test-report-page');
Route::view('/DateWiseTestReportPage', 'pages.back-end-page.date-wise-test-report-page');
Route::view('/allSummeryReportPage', 'pages.back-end-page.all-summery-report-page');


Route::get("/all-summery-report", [ReportController::class, 'AllSummeryReport'])->middleware('auth:sanctum');
// Permission API Route start
Route::get("/list-permission", [RoleController::class, 'PermissionList'])->middleware('auth:sanctum');
Route::post("/create-permission", [RoleController::class, 'PermissionCreate'])->middleware('auth:sanctum');
Route::post("/permission-by-id", [RoleController::class, 'PermissionById'])->middleware('auth:sanctum');
Route::post("/update-permission", [RoleController::class, 'PermissionUpdate'])->middleware('auth:sanctum');

// Roles API Route start
Route::get("/list-roles", [RoleController::class, 'RolesList'])->name('list.roles')->middleware('auth:sanctum');
Route::post("/create-roles", [RoleController::class, 'RolesCreate'])->middleware('auth:sanctum');

// Admin Role API Route start
Route::get("/list-admin", [AdminController::class, 'AdminList'])->name('list.admin');
Route::get("/create-admin", [AdminController::class, 'AdminCreate'])->name('create.admin');
Route::post("/store-admin", [AdminController::class, 'AdminStore'])->name('store.admin');;
// Role In Permission API Route start
Route::get("/create-role-in-permission", [RoleController::class, 'RoleInPermissionCreate']);
Route::post("/store-role-in-permission", [RoleController::class, 'RoleInPermissionStore']);
Route::get("/list-role-in-permission", [RoleController::class, 'RoleInPermissionList'])->name('list.role.in.permission');
Route::get("/edit-role-in-permission/{id}", [RoleController::class, 'RoleInPermissionEdit'])->name('edit.role.in.permission');
Route::post("/update-role-in-permission/{id}", [RoleController::class, 'RoleInPermissionUpdate'])->name('update.role.in.permission');
Route::get("/delete-role-in-permission/{id}", [RoleController::class, 'RoleInPermissionDelete'])->name('delete.role.in.permission');
//Route::post("/create-role-in-permission", [RoleController::class, 'RoleInPermissionCreate'])->middleware('auth:sanctum');

// Test Categorie API Route start
Route::get("/list-test-categorie", [TestCategoryController::class, 'TestCategorieList'])->middleware('auth:sanctum');
Route::post("/create-test-categorie", [TestCategoryController::class, 'TestCategorieCreate'])->middleware('auth:sanctum');
Route::post("/test-categorie-by-id", [TestCategoryController::class, 'TestCategorieById'])->middleware('auth:sanctum');
Route::post("/update-test-categorie", [TestCategoryController::class, 'TestCategorieUpdate'])->middleware('auth:sanctum');
Route::post("/delete-test-categorie", [TestCategoryController::class, 'TestCategorieDelete'])->middleware('auth:sanctum');


//Medical Test API Route start
Route::get("/list-test", [TestController::class, 'TestList'])->middleware('auth:sanctum');
Route::get("/all-test-report", [TestController::class, 'TestReport'])->middleware('auth:sanctum');
Route::get("/date-wise-test-report", [TestController::class, 'DateWiseTestReport'])->middleware('auth:sanctum');
Route::post("/create-test", [TestController::class, 'TestCreate'])->middleware('auth:sanctum');
Route::post("/test-by-id", [TestController::class, 'TestById'])->middleware('auth:sanctum');
Route::post("/update-test", [TestController::class, 'TestUpdate'])->middleware('auth:sanctum');
Route::post("/delete-test", [TestController::class, 'TestDelete'])->middleware('auth:sanctum');

Route::post('/list-by-test', [TestController::class, 'listByTest']);



Route::get("/patients/search", [PatientController::class, 'search'])->middleware('auth:sanctum');




//Patient API Route start
Route::get("/list-patient", [PatientController::class, 'PatientList'])->middleware('auth:sanctum');
Route::post("/create-patient", [PatientController::class, 'PatientCreate'])->middleware('auth:sanctum');
Route::post("/patient-by-id", [PatientController::class, 'PatientById'])->middleware('auth:sanctum');
Route::post("/update-patient", [PatientController::class, 'PatientUpdate'])->middleware('auth:sanctum');
Route::post("/delete-patient", [PatientController::class, 'PatientDelete'])->middleware('auth:sanctum');

// OLD Patient API Route Start
Route::post("/old-patient-by-id", [PatientController::class, 'OLDPatientById'])->middleware('auth:sanctum');
Route::post("/update-old-patient", [PatientController::class, 'OLDPatientUpdate'])->middleware('auth:sanctum');
Route::post("/delete-old-patient", [PatientController::class, 'OLDPatientDelete'])->middleware('auth:sanctum');


// Expenses Categorie API Route start
Route::get("/list-expenses-categorie", [ExpensesCategoryController::class, 'ExpensesCategorieList'])->middleware('auth:sanctum');
Route::post("/create-expenses-categorie", [ExpensesCategoryController::class, 'ExpensesCategorieCreate'])->middleware('auth:sanctum');
Route::post("/expenses-categorie-by-id", [ExpensesCategoryController::class, 'ExpensesCategorieById'])->middleware('auth:sanctum');
Route::post("/update-expenses-categorie", [ExpensesCategoryController::class, 'ExpensesCategorieUpdate'])->middleware('auth:sanctum');
Route::post("/delete-expenses-categorie", [ExpensesCategoryController::class, 'ExpensesCategorieDelete'])->middleware('auth:sanctum');



// Expenses API Route start
Route::get("/list-expenses", [ExpensesController::class, 'ExpensesList'])->middleware('auth:sanctum');
Route::post("/create-expenses", [ExpensesController::class, 'ExpensesCreate'])->middleware('auth:sanctum');
Route::post("/expenses-by-id", [ExpensesController::class, 'ExpensesById'])->middleware('auth:sanctum');
Route::post("/update-expenses", [ExpensesController::class, 'ExpensesUpdate'])->middleware('auth:sanctum');
Route::post("/delete-expenses", [ExpensesController::class, 'ExpensesDelete'])->middleware('auth:sanctum');
Route::get("/date-wise-expenses", [ExpensesController::class, 'ExpensesDateWise'])->middleware('auth:sanctum');


// Response Data API route
Route::get('/invoice-Data',[InvoiceController::class,'index']);
Route::get('/pataient-Data',[InvoiceController::class,'PataientData']);
Route::get('/invoice_details',[InvoiceController::class,'InvoiceDetailsData']);
Route::get('/invoice_print_receipt',[InvoiceController::class,'InvoicePrintReceipt']);

// Dashboard API Route End

// ----------------------------Dashboard Route Work Robiul End-----------------------------------------------------

