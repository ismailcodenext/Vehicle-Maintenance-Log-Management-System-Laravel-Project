<div class="modal animated zoomIn" style="z-index: 99999999 !important;" id="create-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Doctor Add</h5>
            </div>
            <div class="modal-body">
                <form id="save-form">
                    <div class="container" style="padding: 0 10px">
                        <div class="row">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="form-label">Name *</label>
                                        <input type="text" class="form-control test_form_input" id="DoctorName">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">email *</label>
                                <input type="text" class="form-control test_form_input" id="DoctorEmail">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Chamber Address *</label>
                                <input type="text" class="form-control test_form_input" id="ChamberAddress">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Specialization*</label>
                                <input type="text" class="form-control test_form_input" id="Doctorspecialization">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Degree *</label>
                                <input type="text" class="form-control test_form_input" id="DoctorDegree">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Hospital *</label>
                                <input type="text" class="form-control test_form_input" id="DoctorHospital">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">mobile *</label>
                                <input type="text" class="form-control test_form_input" id="DoctorMobile">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">registration_number *</label>
                                <input type="text" class="form-control test_form_input" id="DoctorRegistrationNumber">
                                    </div>

                                    <div class="col-md-6">
                                        <div class="d-flex align-items-center mt-3">
                                            <img class="w-25 me-3" id="newImg" src="<?php echo e(asset('images/default.jpg')); ?>"/>
                                            <div>
                                                <label class="form-label">Photo</label>
                                                <input oninput="newImg.src=window.URL.createObjectURL(this.files[0])" type="file" class="form-control" id="DoctorImage">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button id="modal-close" class="btn modal_close_btn" data-bs-dismiss="modal" aria-label="Close">Close</button>
                    <button onclick="Save()" id="save-btn" class="btn " style="width: auto;">Save</button>
                </div>
            </div>
    </div>
</div>

<script>
    async function Save() {
        try {
            let DoctorEmail = document.getElementById('DoctorEmail').value;
            let ChamberAddress = document.getElementById('ChamberAddress').value;
            let DoctorName = document.getElementById('DoctorName').value;
            let Doctorspecialization = document.getElementById('Doctorspecialization').value;
            let DoctorDegree = document.getElementById('DoctorDegree').value;
            let DoctorHospital = document.getElementById('DoctorHospital').value;
            let DoctorMobile = document.getElementById('DoctorMobile').value;
            let DoctorRegistrationNumber = document.getElementById('DoctorRegistrationNumber').value;
            let imgInput = document.getElementById('DoctorImage');
            let imgFile = imgInput.files[0];

            if (DoctorName.length === 0) {
                errorToast("Doctor Name Required !");
            }

            else if (DoctorEmail.length === 0) {
                errorToast("Doctor Email Required !");
            }

            else if (ChamberAddress.length === 0) {
                errorToast("Chamber Address Required !");
            }

            else if (Doctorspecialization.length === 0) {
                errorToast("Doctors specialization Required !");
            }

            else if (DoctorDegree.length === 0) {
                errorToast("Doctor Degree Required !");
            }

            else if (DoctorHospital.length === 0) {
                errorToast("Doctor Hospital Required !");
            }

            else if (DoctorMobile.length === 0) {
                errorToast("Doctor Mobile Required !");
            }

            else if (DoctorRegistrationNumber.length === 0) {
                errorToast("Doctor Registration Number Required !");
            }

            else if (!imgInput.files || imgInput.files.length === 0) {
                errorToast("Doctor Photo Required !");
                return;
            }

            else {
                document.getElementById('modal-close').click();
                let formData = new FormData();
                formData.append('name',DoctorName );
                formData.append('email',DoctorEmail);
                formData.append('registration_number',DoctorRegistrationNumber );
                formData.append('specialization', Doctorspecialization);
                formData.append('degree', DoctorDegree);
                formData.append('hospital', DoctorHospital);
                formData.append('chamber_address',ChamberAddress );
                formData.append('mobile',DoctorMobile );
                formData.append('img', imgFile);

                const config = {
                    headers: {
                        'content-type': 'multipart/form-data',
                        ...HeaderToken().headers
                    }
                }

                let res = await axios.post("/create-doctor", formData, config);


                if (res.data['status'] === "success") {
                    successToast(res.data['message']);
                    document.getElementById("save-form").reset();
                    await getList();
                } else {
                    errorToast(res.data['message'])
                }
            }

        } catch (e) {
            unauthorized(e.response.status)
        }
    }
</script>
<?php /**PATH C:\xampp\htdocs\DMS\resources\views/components/back-end/doctor/doctor-create.blade.php ENDPATH**/ ?>