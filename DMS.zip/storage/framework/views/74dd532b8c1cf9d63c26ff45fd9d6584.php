<div class="container-fluid" style="padding-top: 20px">
    <div class="wrapper">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="row justify-content-between">
                    <div class="align-items-center col">
                        <h4>All Summary Report</h4>
                    </div>
                </div>
                <div class="container p-0">
                    <div class="wrapper">
                        <div class="row">
                            <div class="col-md-4 col-sm-6 col-lg-3">
                                <label class="form-label">From:</label>
                                <input type="date" id="startDate" class="form-control test_form_input" placeholder="Start Date">
                            </div>
                            <div class="col-md-4 col-sm-6 col-lg-3">
                                <label class="form-label">To:</label>
                                <input type="date" id="endDate" class="form-control test_form_input" placeholder="End Date">
                            </div>
                            <div class="col-md-4 col-sm-12 col-lg-4">
                                <div class="btn_wrapper">
                                    <button class="btn search_btn" onclick="searchReports()">Search</button>
                                    <button class="summery_print_btn" onclick="printTable()">Print Table</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr style="margin: 20px 0; color: #332941;"/>

                <div class="table-responsive">
                    <table class="table invoice_table" id="tableData">
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Total Tests</th>
                            <th>Pathology Department</th>
                            <th>Ultrasound Department</th>
                            <th>Hormone Department</th>
                            <th>ECG Department</th>
                            <th>Total Amount</th>
                            <th>Total Discount</th>
                            <th>Total Amount After Discount</th>
                            <th>Sonologist Payment</th>
                            <th>PC Commission</th>
                            <th>Others Expense</th>
                            <th>Balance</th>
                        </tr>
                        </thead>
                        <tbody id="tableList"></tbody>
                        <tfoot>
                        <tr id="totalCounts">
                            <th colspan="1">Total</th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                        </tfoot>
                    </table>
                </div>

                <!-- Print Table Button -->


            </div>
        </div>
    </div>

</div>

<script>
    // Function to print only the table content
    function printTable() {
        // Get the table content
        var tableContent = document.getElementById('tableData').outerHTML;

        // Open a new window
        var printWindow = window.open('', '_blank');
        printWindow.document.open();

        // Add the table content to the new window
        printWindow.document.write('<html><head><title>Print Table</title></head><body>');
        printWindow.document.write(tableContent);
        printWindow.document.write('</body></html>');

        // Close the document
        printWindow.document.close();

        // Print the table in the new window
        printWindow.print();
    }
    async function searchReports() {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;

        try {
            const res = await axios.get(`/all-summery-report?start_date=${startDate}&end_date=${endDate}`, HeaderToken());

            // Process response data and update table
            updateTable(res.data.reportData);
        } catch (error) {
            handleError(error);
        }
    }

    function updateTable(reportData) {
        const tableList = $("#tableList");
        const tableData = $("#tableData");

        // Clear existing table data
        tableData.DataTable().destroy();
        tableList.empty();

        // Update table rows with report data
        reportData.forEach(report => {
            const row = `
            <tr>
                <td>${report.date}</td>
                <td>${report.total_count_tests}</td>
                <td>${report.pathology_total}</td>
                <td>${report.ultrasound_total}</td>
                <td>${report.hormone_total}</td>
                <td>${report.ecg_total}</td>
                <td>${report.total_tests}</td>
                <td>${report.total_discount_amount}</td>
                <td>${report.total_paid_amount}</td>
                <td>${report.sonologist_total}</td>
                <td>${report.pc_commission_total}</td>
                <td>${report.others_expense_total}</td>
                <td>${ report.total_paid_amount - (report.sonologist_total + report.pc_commission_total + report.others_expense_total) }</td>
            </tr>`;
            tableList.append(row);
        });

        // Calculate and update totals
        const totals = calculateTotals(reportData);
        updateTotalRow(totals);

        $(document).ready(function() {
            $('#tableData').DataTable({
                dom: 'Bfrtip',
                buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
            });
        });
    }

    function calculateTotals(reportData) {
        return reportData.reduce((acc, report) => {
            acc.totalCountTest += parseFloat(report.total_count_tests);
            acc.pathologyTotal += parseFloat(report.pathology_total);
            acc.ultrasoundTotal += parseFloat(report.ultrasound_total);
            acc.hormoneTotal += parseFloat(report.hormone_total);
            acc.ecgTotal += parseFloat(report.ecg_total);
            acc.totalTest += parseFloat(report.total_tests);
            acc.totalDiscountAmount += parseFloat(report.total_discount_amount);
            acc.totalPaidAmount += parseFloat(report.total_paid_amount);
            acc.sonologistTotal += parseFloat(report.sonologist_total);
            acc.pcCommisionTotal += parseFloat(report.pc_commission_total);
            acc.otherExpenseTotal += parseFloat(report.others_expense_total);
            acc.balance += parseFloat(report.total_paid_amount) - (parseFloat(report.sonologist_total) + parseFloat(report.pc_commission_total) + parseFloat(report.others_expense_total));
            return acc;
        }, {
            totalCountTest: 0,
            pathologyTotal: 0,
            ultrasoundTotal: 0,
            hormoneTotal: 0,
            ecgTotal: 0,
            totalTest: 0,
            totalDiscountAmount: 0,
            totalPaidAmount: 0,
            sonologistTotal: 0,
            pcCommisionTotal: 0,
            otherExpenseTotal: 0,
            balance: 0
        });
    }

    function updateTotalRow(totals) {
        const totalCountsRow = `
        <tr id="totalCounts">
            <th colspan="1">Total</th>
            <th>${totals.totalCountTest.toFixed(2)}</th>
            <th>${totals.pathologyTotal.toFixed(2)}</th>
            <th>${totals.ultrasoundTotal.toFixed(2)}</th>
            <th>${totals.hormoneTotal.toFixed(2)}</th>
            <th>${totals.ecgTotal.toFixed(2)}</th>
            <th>${totals.totalTest.toFixed(2)}</th>
            <th>${totals.totalDiscountAmount.toFixed(2)}</th>
            <th>${totals.totalPaidAmount.toFixed(2)}</th>
            <th>${totals.sonologistTotal.toFixed(2)}</th>
            <th>${totals.pcCommisionTotal.toFixed(2)}</th>
            <th>${totals.otherExpenseTotal.toFixed(2)}</th>
            <th>${totals.balance.toFixed(2)}</th>
            <th></th>
        </tr>`;
        $('#tableData tfoot').empty().append(totalCountsRow);
    }

    function handleError(error) {
        if (error.response && error.response.status === 401) {
            unauthorized(error.response.status);
        } else {
            console.error("An error occurred:", error);
            // Handle other errors gracefully
        }
    }


    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("startDate");
        flatpickr(inputField, {
            dateFormat: "Y-m-d",
            defaultDate: "today",
            onClose: function(selectedDates, dateStr, instance) {
                inputField.value = dateStr;
            }
        });
    });


    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("endDate");
        flatpickr(inputField, {
            dateFormat: "Y-m-d",
            defaultDate: "today",
            onClose: function(selectedDates, dateStr, instance) {
                inputField.value = dateStr;
            }
        });
    });


</script>

<?php /**PATH C:\xampp\htdocs\DMS\resources\views/components/back-end/report/all-summery-report.blade.php ENDPATH**/ ?>