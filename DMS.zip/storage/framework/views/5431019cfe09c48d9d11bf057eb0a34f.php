<div class="container-fluid" style="padding-top: 20px">
    <div class="wrapper">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="row justify-content-between">
                    <div class="align-items-center col">
                        <h4>Date Wise Test Report</h4>
                    </div>
                    <div class="col-12">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Start Date:</label>
                                <input type="date" class="form-control test_form_input" id="startDate">
                            </div>

                            <div class="col-md-4">
                                <label>End Date:</label>
                                <input type="date" class="form-control test_form_input" id="endDate">
                            </div>

                            <div class="col-md-4">
                                <button class="btn search_btn" id="searchBtn">Search</button>
                            </div>

                        </div>
                    </div>
                </div>

                <hr style="margin: 20px 0; color: #332941;"/>

                <div class="table-responsive">
                    <table class="table invoice_table" id="tableData">
                        <thead>
                        <tr>
                            <th>Test ID</th>
                            <th>Test Name</th>
                            <th>Test Quantity</th>
                            <th>Unit Price</th>
                            <th>Total Price</th>
                        </tr>
                        </thead>
                        <tbody id="tableList"></tbody>
                        <tfoot>
                        <tr id="totalCounts">
                            <th colspan="1">Total</th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        let tableData = null;

        $('#searchBtn').on('click', function () {
            let startDate = $('#startDate').val();
            let endDate = $('#endDate').val();
            getList(startDate, endDate);
        });

        async function getList(startDate, endDate) {
            try {
                showLoader(); // Assuming this function is defined elsewhere
                let res = await axios.get("/date-wise-test-report", {
                    ...HeaderToken(),
                    params: {
                        start_date: startDate,
                        end_date: endDate
                    }
                });
                hideLoader(); // Assuming this function is defined elsewhere

                let tableList = $("#tableList");
                tableData = $("#tableData");

                tableData.DataTable().destroy();
                tableList.empty();

                res.data['testReportData'].forEach(function (item, index) {
                    let row = `<tr>
                                    <td>${item.test_id}</td>
                                    <td>${item.test_name}</td>
                                    <td>${item.test_quantity}</td>
                                    <td>${item.unit_price}</td>
                                    <td>${item.total_price}</td>
                                </tr>`;
                    tableList.append(row);
                });

                // Calculate totals
                let testQuantity = 0;
                let unitPrice = 0;
                let totalPrice = 0;

                res.data['testReportData'].forEach(function (item, index) {
                    testQuantity += parseFloat(item['test_quantity']);
                    unitPrice += parseFloat(item['unit_price']);
                    totalPrice += parseFloat(item['total_price']);
                });

                // Append totals to the footer
                let totalCountsRow = `
                <tr id="totalCounts">
                    <th colspan="2">Total</th>
                    <th>${testQuantity.toFixed(2)}</th>
                    <th>${unitPrice.toFixed(2)}</th>
                    <th>${totalPrice.toFixed(2)}</th>
                </tr>`;
                $('#tableData tfoot').empty().append(totalCountsRow); // Append to table footer

                tableData.DataTable({
                    layout: {
                        topStart: {
                            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
                        }
                    }
                });

            } catch (e) {
                unauthorized(e.response.status); // Assuming this function is defined elsewhere
            }
        }
    });


    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("startDate");
        flatpickr(inputField, {
            dateFormat: "Y-m-d",
            defaultDate: "today",
            onClose: function(selectedDates, dateStr, instance) {
                inputField.value = dateStr;
            }
        });
    });


    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("endDate");
        flatpickr(inputField, {
            dateFormat: "Y-m-d",
            defaultDate: "today",
            onClose: function(selectedDates, dateStr, instance) {
                inputField.value = dateStr;
            }
        });
    });

</script>

<?php /**PATH C:\xampp\htdocs\DMS\resources\views/components/back-end/test/date-wise-test-report-page.blade.php ENDPATH**/ ?>