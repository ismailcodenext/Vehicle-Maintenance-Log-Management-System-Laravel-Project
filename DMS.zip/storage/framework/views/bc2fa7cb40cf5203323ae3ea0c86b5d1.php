<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MDH PABNA</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Styles  -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />

    <!-- Box Icons  -->
    <link
        href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
        rel="stylesheet"
    />

    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('/favicon.ico')); ?>"/>
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/animate.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet"/>

    <link href="<?php echo e(asset('css/print-invoice.css')); ?>" rel="stylesheet"/>

    <link href="<?php echo e(asset('css/toastify.min.css')); ?>" rel="stylesheet"/>

    <script src="https://kit.fontawesome.com/b981429a8a.js" crossorigin="anonymous"></script>

    <link href="<?php echo e(asset('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css')); ?>" rel="stylesheet" />


    <script src="<?php echo e(asset('js/toastify-js.js')); ?>"></script>
    <script src="<?php echo e(asset('js/axios.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/config.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.js')); ?>"></script>

    <!-- Include Summernote CSS start -->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.css" rel="stylesheet">
    <link href="<?php echo e(asset('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css')); ?>" rel="stylesheet" />


    <!-- Include Summernote js end -->
    <link href="https://cdn.datatables.net/2.0.4/css/dataTables.dataTables.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/3.0.2/css/buttons.dataTables.css" rel="stylesheet" />

    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdn.datatables.net/2.0.4/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.2/js/dataTables.buttons.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.dataTables.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.print.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.html5.min.js"></script>


    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


    <!-- Include flatpickr CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

    <!-- Include flatpickr JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>


    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>
<div id="loader" class="LoadingOverlay d-none">
    <div class="Line-Progress">
        <div class="indeterminate"></div>
    </div>
</div>
<!-- Sidebar Start -->
<div class="sidebar">
    <div class="toggle-sidebar">
        <i class="bx bx-chevrons-left"></i>
    </div>

    <a class="navbar-brand" href="#">
        <img class="nav-logo  mx-2" src="<?php echo e(asset('images/logo.jpg')); ?>" alt="logo"/>
    </a>

    <ul class="sidebar-list">
        <li>
            <div class="title">
                <a href="<?php echo e(url("/dashboardSummary")); ?>" class="link">
                    <i class="bx bx-grid-alt"></i>
                    <span class="name">Dashboard</span>
                </a>
            </div>
            <div class="submenu">
                <a href="<?php echo e(url("/dashboardSummary")); ?>" class="link submenu-title">Dashboard</a>
            </div>
        </li>

        <li class="dropdown">
            <div class="title">
                <a href="#" class="link">
                    <i class="fa-solid fa-hospital-user"></i>
                    <span class="name">Patient Management</span>
                </a>
                <i class="bx bxs-chevron-down"></i>
            </div>
            <div class="submenu">
                <a href="<?php echo e(url('/patientsPage')); ?>" class="link">Patients List</a>
            </div>
        </li>

        <li class="dropdown">
            <div class="title">
                <a href="#" class="link">
                    <i class="fa-solid fa-user-doctor"></i>
                    <span class="name">Doctor Management</span>
                </a>
                <i class="bx bxs-chevron-down"></i>
            </div>
            <div class="submenu">
                <a href="<?php echo e(url('/doctorpage')); ?>" class="link">Doctor List</a>
            </div>
        </li>


        <li class="dropdown">
            <div class="title">
                <a href="#" class="link">
                    <i class="fa-solid fa-person-circle-plus"></i>
                    <span class="name">PC Management</span>
                </a>
                <i class="bx bxs-chevron-down"></i>
            </div>
            <div class="submenu">
                <a href="<?php echo e(url('/pcPage')); ?>" class="link">PC List</a>
            </div>
        </li>

        <li class="dropdown">
            <div class="title">
                <a href="#" class="link">
                    <i class="fa-solid fa-flask-vial"></i>
                    <span class="name">Test Management</span>
                </a>
                <i class="bx bxs-chevron-down"></i>
            </div>
            <div class="submenu">
                <a href="<?php echo e(url('/testCategoryPage')); ?>" class="link">Test Category List</a>
                <a href="<?php echo e(url('/testPage')); ?>" class="link">Test List</a>
                <a href="<?php echo e(url('/AllTestReportPage')); ?>" class="link">All Test Report</a>
                <a href="<?php echo e(url('/DateWiseTestReportPage')); ?>" class="link">Date Wise Test Report</a>
            </div>
        </li>
        <li class="dropdown">
            <div class="title">
                <a href="#" class="link">
                    <i class="fa-solid fa-money-bill-trend-up"></i>
                    <span class="name">Expenses Management</span>
                </a>
                <i class="bx bxs-chevron-down"></i>
            </div>
            <div class="submenu">

                <a href="<?php echo e(url('/expensesPage')); ?>" class="link">Expenses List</a>
                <a href="<?php echo e(url('/dateWiseExpensesPage')); ?>" class="link">Date Wise Expenses Report</a>
            </div>
        </li>


        <li class="dropdown">
            <div class="title">
                <a href="#" class="link">
                    <i class="fa-solid fa-file-invoice"></i>
                    <span class="name">Invoice Management</span>
                </a>
                <i class="bx bxs-chevron-down"></i>
            </div>
            <div class="submenu">
                <a href="<?php echo e(url('/invoicePage')); ?>" class="link">Create New Patient Invoice</a>
                <a href="<?php echo e(url('/oldPatientsPage')); ?>" class="link">Create OLD Patient Invoice</a>
                <a href="<?php echo e(url('/allInvoiceReportPage')); ?>" class="link">All Invoice Report</a>
                <a href="<?php echo e(url('/dateWiseInvoiceReportPage')); ?>" class="link">Date Wise Invoice Report</a>
                <a href="<?php echo e(url('/patientWiseInvoiceReportPage')); ?>" class="link">Patient Wise Invoice Report</a>
                <a href="<?php echo e(url('/PCWiseInvoiceReportPage')); ?>" class="link">PC Wise Invoice Report</a>
                <a href="<?php echo e(url('/allDueInvoiceReportPage')); ?>" class="link">All Due Invoice Report</a>
                <a href="<?php echo e(url('/allSummeryReportPage')); ?>" class="link">All Summery Report</a>
            </div>
        </li>


    </ul>
</div>
<!-- Sidebar End -->

<!-- Home Start -->
<section class="home">
    <!-- navbar start -->
    <nav class="navbar">
        <div class="nav_logo">
          <h3>Modern Diagnostic Home</h3>
        </div>

        <div class="nav_search_box">







        </div>

        <div class="nav_items">
            <!-- <div class="search_box">
              <span>
                <i class="bx bx-search-alt"></i>
              </span>
              <input type="text" placeholder="Search..." />
            </div> -->

            <div class="float-right d-flex align-items-center nav_items">
                <li class="dropdown_nav">
                    <a class="text-center text-dark nav_link" href="<?php echo e(url('/invoicePage')); ?>" style="font-size: 16px; position: relative;"><i class="fa-solid fa-pen-to-square"></i> <span>Create Invoice</span> <i class="fa-solid fa-chevron-down"></i>
                        <ul class="nav_dropdown_items">
                            <li>
                                <a href="<?php echo e(url('/invoicePage')); ?>" class="dropdown_nav_link"><i class="fa-solid fa-pen-to-square"></i> New Patient Invoice</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/oldPatientsPage')); ?>" class="dropdown_nav_link"><i class="fa-solid fa-pen-to-square"></i> Old Patient Invoice</a>
                            </li>
                        </ul>
                    </a>
                </li>
                <a class="text-center ms-4 me-4 text-dark nav_link" href="<?php echo e(url('/dateWiseInvoiceReportPage')); ?>" style="font-size: 16px;"><i class="fa-solid fa-file-invoice"></i> <span>Invoice Report</span></a>
                <a class="text-center ms-4 text-dark nav_link" href="<?php echo e(url('/allSummeryReportPage')); ?>" style="font-size: 16px;"><i class="fa-solid fa-receipt"></i> <span>Summery Report</span></a>
                <a class="text-center ms-4 me-4 text-dark nav_link" href="<?php echo e(url('/expensesPage')); ?>" style="font-size: 16px;"><i class="fa-solid fa-money-bill-transfer"></i></i> <span>Expense</span></a>
                <div class="user-dropdown">
                    <img class="icon-nav-img" id="UserProfileImg" src="" alt=""/>
                    <div class="user-dropdown-content">
                        <div class="mt-4 text-center">
                            <img class="icon-nav-img" id="UserImges" src="" alt=""/>
                            <h6 id="Name"></h6>
                            <hr class="user-dropdown-divider  p-0"/>
                        </div>
                        <a href="<?php echo e(url('/userProfile')); ?>" class="profileBtn">
                            <span class="side-bar-item-caption" style="font-weight: 500; font-size: 1em">Profile</span>
                        </a>
                        <button  onclick="userlogout()" class="logoutBtn">
                            <span class="side-bar-item-caption" style="font-weight: 500; font-size: 1.2em">Logout</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- navbar end -->

    <!-- Content Start -->
    <div class="main_content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- Content End -->

    <!-- Footer Start -->
    <footer id="footer">
        <p>&copy; Copyright 2024 |Developed By <a href="https://www.codenextit.com" style="font-size: 14px; color: #0dcaf0;">CodeNext IT</a></p>
    </footer>
    <!-- Footer End -->
</section>
<!-- Home End -->

<!-- Script -->
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>


<script>
    async function userlogout() {

        try {
            let res = await axios.get("/userlogout", HeaderToken());
            localStorage.clear();
            sessionStorage.clear();
            window.location.href = "/diagnostic-login-page";
        } catch (e) {
            errorToast(res.data['message']);
        }
    }

</script>


<script>
    getProfile();

    async function getProfile() {
        try {
            showLoader();
            let res = await axios.get("/user-profile", HeaderToken());
            hideLoader();
            document.getElementById('UserProfileImg').src = res.data.img_url;
            document.getElementById('UserImges').src = res.data.img_url;
            document.getElementById('Name').innerText = res.data['firstName'];
        } catch (e) {
            unauthorized(e.response.status)
        }
    }
</script>

</script>
<script>
    $('#ExpensesNote').summernote({
        placeholder: 'Content',
        tabsize: 2,
        height: 100
    });
</script>
<script>
    $('#UpdateExpensesNote').summernote({
        placeholder: 'Update Content',
        tabsize: 2,
        height: 100
    });
</script>



</body>
</html>
<?php /**PATH C:\xampp\htdocs\DMS\resources\views/layout/sidenav-layout.blade.php ENDPATH**/ ?>