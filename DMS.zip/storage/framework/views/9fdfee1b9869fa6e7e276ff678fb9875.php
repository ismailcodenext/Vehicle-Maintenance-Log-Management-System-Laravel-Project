<div class="container-fluid" style="padding-top: 20px">
    <div class="wrapper">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="row justify-content-between">
                    <div class="align-items-center col">
                        <h4>All Test Report</h4>
                    </div>
                </div>

                <hr style="margin: 20px 0; color: #332941;"/>

                <div class="table-responsive">
                    <table class="table invoice_table" id="tableData">
                        <thead>
                        <tr>
                            <th>Test ID</th>
                            <th>Test Name</th>
                            <th>Test Quantity</th>
                            <th>Unit Price</th>
                            <th>Total Price</th>
                        </tr>
                        </thead>
                        <tbody id="tableList"></tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

</div>

<script>
    getList()
    async function getList() {
        try {
            let res = await axios.get("/all-test-report", HeaderToken());
            let tableList = $("#tableList");
            let tableData = $("#tableData");

            showLoader();
            tableData.DataTable().destroy();
            tableList.empty();
            hideLoader();

            res.data['testReportData'].forEach(function (item, index) {
                let row = `<tr>
                                <td>${item.test_id}</td>
                                <td>${item.test_name}</td>
                                <td>${item.test_quantity}</td>
                                <td>${item.unit_price}</td>
                                <td>${item.total_price}</td>
                            </tr>`;
                tableList.append(row);
            });

            new DataTable('#tableData', {
                layout: {
                    topStart: {
                        buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
                    }
                }
            });

        } catch (e) {
            unauthorized(e.response.status)
        }
    };
</script>
<?php /**PATH C:\xampp\htdocs\DMS\resources\views/components/back-end/test/all-test-report.blade.php ENDPATH**/ ?>