<div class="modal animated zoomIn" id="create-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title" id="exampleModalLabel">Test Create</h6>
            </div>
            <div class="modal-body">
                <form id="save-form">
                    <div class="container" style="padding: 0 10px">
                        <div class="row">
                            <div class="col-12 p-1">
                                <label class="form-label">Test Category *</label>
                                <select class="form-select" id="TestCategorie" aria-label="Default select example">
                                    <option value="">Select Category</option>
                                </select>
                                <label class="form-label">Test Name *</label>
                                <input type="text" class="form-control test_form_input" id="TestName">
                                <label class="form-label">Department <span class="text-danger">*</span></label>
                                <select class="form-select" id="testDepartment" aria-label="Default select example">
                                    <option value="">Select Department</option>
                                    <option value="Pathology">Pathology</option>
                                    <option value="Microbiology">Microbiology</option>
                                    <option value="Ultrasound">Ultrasound</option>
                                    <option value="Hormone">Hormone</option>
                                    <option value="ECG">ECG</option>
                                </select>
                                <label class="form-label">Price *</label>
                                <input type="text" class="form-control test_form_input" id="Price">
                                <label class="form-label">Commission *</label>
                                <input type="text" class="form-control test_form_input" id="Commission">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button id="modal-close" class="btn modal_close_btn" data-bs-dismiss="modal" aria-label="Close">Close</button>
                <button onclick="Save()" id="save-btn" class="btn" style="width: auto;">Save</button>
            </div>
        </div>
    </div>
</div>

<script>
    FillClassNameDropDown();

    async function FillClassNameDropDown() {
        try {
            let res = await axios.get("/list-test-categorie", HeaderToken());
            let testCategories = res.data.TestCategorie_data;
            let optionsHtml = testCategories.map(category => `<option value="${category.id}">${category.category_name}</option>`).join('');
            $("#TestCategorie").append(optionsHtml);
        } catch (error) {
            console.error("Error occurred while fetching test categories:", error);
        }
    }

    async function Save() {
        try {
            let testName = document.getElementById('TestName').value;
            let price = document.getElementById('Price').value;
            let commission = document.getElementById('Commission').value;
            let testCategoryId = document.getElementById('TestCategorie').value;
            let testDepartment = document.getElementById('testDepartment').value;

            if (testName.length === 0) {
                errorToast("Test Name Required!");
            } else if (price.length === 0) {
                errorToast("Price Required!");
            } else if (commission.length === 0) {
                errorToast("Commission Required!");
            } else if (testCategoryId.length === 0) {
                errorToast("Test Category Required!");
            } else if (testDepartment.length === 0) {
                errorToast("Test Department Required!");
            }
            else {
                document.getElementById('modal-close').click();
                let formData = new FormData();
                formData.append('test_name', testName);
                formData.append('price', price);
                formData.append('commission', commission);
                formData.append('test_category_id', testCategoryId);
                formData.append('department', testDepartment);

                const config = {
                    headers: {
                        'content-type': 'multipart/form-data',
                        ...HeaderToken().headers
                    }
                }

                showLoader();
                let res = await axios.post("/create-test", formData, config);
                hideLoader();

                if (res.data.status === "success") {
                    successToast(res.data.message);
                    document.getElementById("save-form").reset();
                    await getList();
                } else {
                    errorToast(res.data.message);
                }
            }

        } catch (error) {
            unauthorized(error.response.status);
        }
    }
</script>
<?php /**PATH C:\xampp\htdocs\DMS\resources\views/components/back-end/test/test-page-create.blade.php ENDPATH**/ ?>