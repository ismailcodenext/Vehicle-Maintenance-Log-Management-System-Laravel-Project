<?php $__env->startSection('title','Invoice Report'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.back-end.invoice-report.all-due-invoice-report', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.back-end.invoice-report.pay-due-invoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.sidenav-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DMS\resources\views/pages/back-end-page/all-due-invoice-report-page.blade.php ENDPATH**/ ?>