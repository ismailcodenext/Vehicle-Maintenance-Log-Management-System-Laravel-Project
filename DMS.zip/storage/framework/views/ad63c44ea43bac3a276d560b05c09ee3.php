<?php $__env->startSection('title','Expenses Categorie'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.back-end.expenses-categorie.expenses-categorie-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.back-end.expenses-categorie.expenses-categorie-create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.back-end.expenses-categorie.expenses-categorie-update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.back-end.expenses-categorie.expenses-categorie-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.sidenav-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DMS\resources\views/pages/back-end-page/expenses-categorie-page.blade.php ENDPATH**/ ?>