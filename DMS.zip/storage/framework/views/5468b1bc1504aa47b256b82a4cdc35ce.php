<div class="modal animated zoomIn" id="update-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Expenses</h5>
            </div>
            <div class="modal-body">
                <form id="update-form">
                    <div class="container" style="padding: 0 10px;">
                        <div class="row">
                            <div class="col-12 p-1">
                                <label class="form-label"> Name *</label>
                                <input type="text" class="form-control test_form_input" id="ExpensesNameUpdate">
                                <label class="form-label"> Amount *</label>
                                <input type="text" class="form-control test_form_input" id="ExpensesAmountUpdate">
                                <label class="form-label"> Expense Details *</label>
                                <textarea  class="form-control test_form_input textarea expense_textarea"  id="UpdateExpensesNote" cols="30" rows="10"></textarea>
                                <label class="form-label"> Date *</label>
                                <input type="date" class="form-control test_form_input"  id="ExpensesDateUpdate">


                                <input class="d-none" id="updateID">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button id="update-modal-close" class="btn modal_close_btn" data-bs-dismiss="modal" aria-label="Close">Close</button>
                <button onclick="Update(event)" id="update-btn" class="btn modal_update_btn" >Update</button>
            </div>
        </div>
    </div>
</div>

<script>

async function FillUpUpdateForm(id) {
    try {
        document.getElementById('updateID').value = id;
        showLoader();
        let res = await axios.post("/expenses-by-id", { id: id.toString() }, HeaderToken());
        hideLoader();

        let data = res.data.rows;
        document.getElementById('ExpensesNameUpdate').value = data.name;
        document.getElementById('ExpensesAmountUpdate').value = data.amount;
        // Set Summernote content
        $('#UpdateExpensesNote').summernote('code', data.expense_note);
        document.getElementById('ExpensesDateUpdate').value = data.date;
        // document.getElementById('UpdateExpensesCategorieID').value = data.expenses_categories_id;
    } catch (e) {
        unauthorized(e.response.status);
    }
}


async function Update() {
    try {
        let ExpensesNameUpdate = document.getElementById('ExpensesNameUpdate').value;
        let ExpensesAmountUpdate = document.getElementById('ExpensesAmountUpdate').value;
        let UpdateExpensesNote = $('#UpdateExpensesNote').summernote('code');
        let ExpensesDateUpdate = document.getElementById('ExpensesDateUpdate').value;
        // let ExpensesCategorieID = document.getElementById('UpdateExpensesCategorieID').value; // Ensure this is the value, not the element
        let updateID = document.getElementById('updateID').value;

        document.getElementById('update-modal-close').click();

        let formData = new FormData();
        formData.append('name', ExpensesNameUpdate);
        formData.append('amount', ExpensesAmountUpdate);
        formData.append('expense_note', UpdateExpensesNote);
        formData.append('date', ExpensesDateUpdate);
        // formData.append('expenses_categories_id', ExpensesCategorieID); // Append the value, not the element
        formData.append('id', updateID);

        const config = {
            headers: {
                'content-type': 'multipart/form-data',
                ...HeaderToken().headers
            }
        };

        showLoader();

        let res = await axios.post("/update-expenses", formData, config);
        hideLoader();

        if (res.data.status === "success") {
            successToast(res.data.message);
            let modal = new bootstrap.Modal(document.getElementById('update-modal'));
            modal.hide();
            await getList();
        } else {
            errorToast(res.data.message);
        }

    } catch (e) {
        unauthorized(e.response.status);
    }
}

</script>
<?php /**PATH C:\xampp\htdocs\DMS\resources\views/components/back-end/expenses/expenses-update.blade.php ENDPATH**/ ?>