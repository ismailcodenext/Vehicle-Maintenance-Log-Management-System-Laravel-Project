<style>
    @media print {
        body * {
            visibility: hidden;
        }

        #invoices-table,
        #invoices-table * {
            visibility: visible;
        }

        #invoices-table {
            position: fixed;
            left: 0;
            top: 0;
        }
    }
</style>

<div class="container-fluid" style="padding-top: 20px">
    <!-- Search form -->
    <div class="row">
        <div class="col-12">
            <div class="wrapper">
                <h2 class="text-center text-dark" style="font-size: 1.4em; font-weight: 600;">Search Invoices by PC ID</h2>

                <form id="searchForm">
                    <div class="row">

                        <div class="col-lg-4 col-md-6">
                            <label for="pcId" class="form-label text-md-right">PC ID</label>
                            <input id="pcId" type="text" class="form-control test_form_input" name="pc_id" required autofocus>
                        </div>

                        <div class="col-lg-8 col-md-6">
                            <button type="submit" class="btn search_btn">
                                Search
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <!-- Invoices table -->
    <div class="row" style="padding-top: 20px">
        <div class="col-12">
            <div class="wrapper">
                <div class="row">
                    <div class="col-3">
                        <h2 class="text-start text-dark" style="font-size: 1.4em; font-weight: 600;">Invoices</h2>
                    </div>

                    <div class="col-9 d-flex justify-content-end">
                        <button class="btn excel_btn" onclick="exportToExcel()">Export</button>
                        <button class="btn print_btn" onclick="printTable()">Print</button>
                    </div>

                </div>

                <!-- Pc details -->
                <div class="row">
                    <div class="col-md-12">
                        <div id="pc-details" class="d-none">
                            <div class="row" style="border-bottom: 1px solid #016a70; padding-bottom: 15px; margin-bottom: 20px;">
                                <div class="col-md-2">
                                    <strong style="font-size: 1.2em; color: #000; font-weight: 500;">PC Details:</strong>
                                </div>

                                <div class="col-md-2">
                                    <strong style="font-size: 1.2em; color: #000; font-weight: 500;">PC ID:</strong> <span style="font-size: 1.2em;" id="pcIdDisplay"></span>
                                </div>

                                <div class="col-md-3">
                                    <strong style="font-size: 1.2em; color: #000; font-weight: 500;">Name:</strong> <span style="font-size: 1.2em;" id="pcNameDisplay"></span>
                                </div>

                                <div class="col-md-3">
                                    <strong style="font-size: 1.2em; color: #000; font-weight: 500;">Mobile:</strong> <span style="font-size: 1.2em;" id="pcMobileDisplay"></span>
                                </div>

                                <div class="col-md-2">
                                    <strong style="font-size: 1.2em; color: #000; font-weight: 500;">Age:</strong> <span style="font-size: 1.2em;" id="pcAgeDisplay"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table invoice_table" id="invoices-table">
                        <!-- Table headers -->
                        <thead>
                        <tr>
                            <th>Invoice Reg</th>
                            <th>Invoice Date</th>
                            <th>Subtotal</th>
                            <th>Discount</th>
                            <th>Paid</th>
                            <th>Due</th>
                        </tr>
                        </thead>
                        <!-- Table body for invoices -->
                        <tbody id="invoices-table-body">
                        <!-- Data will be dynamically added here -->
                        </tbody>
                        <!-- Table footer for totals -->
                        <tfoot id="totals-row">
                        <tr>
                            <td colspan="2">Total</td> <!-- Adjusted colspan for Invoice Reg and Invoice Date -->
                            <td id="subtotal-total">0</td>
                            <td id="discount-amount-total">0</td>
                            <td id="paid-amount-total">0</td>
                            <td id="due-amount-total">0</td>
                        </tr>
                        </tfoot>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.21.1/axios.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.0/xlsx.full.min.js"></script>
<script>

    // Function to handle form submission
    document.getElementById('searchForm').addEventListener('submit', function (event) {
        event.preventDefault();
        let pcId = document.getElementById('pcId').value;

        // Fetch patient details and invoices data using Axios with header token
        axios.get(`/invoices-by-pc/${pcId}`, HeaderToken())
            .then(function (response) {
                // Handle success
                var data = response.data;
                if (data.success) {
                    var pc = data.pc;
                    var invoices = data.invoices;

                    // Display pc details
                    document.getElementById('pcIdDisplay').textContent = pc.id;
                    document.getElementById('pcNameDisplay').textContent = pc.name;
                    document.getElementById('pcMobileDisplay').textContent = pc.mobile;
                    document.getElementById('pcAgeDisplay').textContent = pc.age;

                    // Show pc details card
                    document.getElementById('pc-details').classList.remove('d-none');

                    var tableBody = document.getElementById('invoices-table-body');
                    var totalsRow = document.getElementById('totals-row');

                    // Clear previous data
                    tableBody.innerHTML = '';
                    totalsRow.innerHTML = '<tr><td colspan="2">Total</td><td id="subtotal-total">0</td><td id="discount-amount-total">0</td><td id="paid-amount-total">0</td><td id="due-amount-total">0</td></tr>';

                    // Initialize totals
                    var subtotalTotal = 0;
                    var discountAmountTotal = 0;
                    var paidAmountTotal = 0;
                    var dueAmountTotal = 0;

                    // Populate table rows with invoices data and calculate totals
                    invoices.forEach(function (invoice) {
                        // Add row data to the table body
                        var row = `<tr>
                            <td>${invoice.invoice_reg}</td>
                            <td>${invoice.invoice_date}</td>
                            <td>${invoice.subtotal}</td>
                            <td>${invoice.discount_amount}</td>
                            <td>${invoice.paid_amount}</td>
                            <td>${invoice.due_amount}</td>
                        </tr>`;
                        tableBody.insertAdjacentHTML('beforeend', row);

                        // Update totals
                        subtotalTotal += parseFloat(invoice.subtotal);
                        discountAmountTotal += parseFloat(invoice.discount_amount);
                        paidAmountTotal += parseFloat(invoice.paid_amount);
                        dueAmountTotal += parseFloat(invoice.due_amount);
                    });

                    // Update total amounts
                    document.getElementById('subtotal-total').textContent = subtotalTotal.toFixed(2);
                    document.getElementById('discount-amount-total').textContent = discountAmountTotal.toFixed(2);
                    document.getElementById('paid-amount-total').textContent = paidAmountTotal.toFixed(2);
                    document.getElementById('due-amount-total').textContent = dueAmountTotal.toFixed(2);
                } else {
                    // Show error message if success is false
                    console.error('Error fetching invoices:', data.message);
                }
            })
            .catch(function (error) {
                // Handle error
                console.error('Error fetching invoices:', error);
            });
    });

    // Function to export data to Excel
    function exportToExcel() {
        var wb = XLSX.utils.table_to_book(document.getElementById('invoices-table'));
        XLSX.writeFile(wb, 'invoices.xlsx');
    }

    // Function to print the table
    function printTable() {
        window.print();
    }
</script>
<?php /**PATH C:\xampp\htdocs\DMS\resources\views/components/back-end/invoice-report/pc-wise-invoice-report.blade.php ENDPATH**/ ?>