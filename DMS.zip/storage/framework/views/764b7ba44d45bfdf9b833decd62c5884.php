<div class="modal animated zoomIn"  id="create-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title" id="exampleModalLabel">New Expenses Create</h6>
            </div>
            <div class="modal-body">
                <form id="save-form">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 p-1">
                                <label class="form-label"> Name *</label>
                                <select class="form-select" id="ExpensesName" aria-label="Default select example">
                                    <option value="Sonologist Payment">Sonologist Payment</option>
                                    <option value="PC Commission">PC Commission</option>
                                    <option value="Others Expense">Others Expense</option>
                                </select>
                                <label class="form-label"> Expense Details *</label>
                                <textarea  class="form-control test_form_input textarea expense_textarea"  id="ExpensesNote" cols="30" rows="10"></textarea>
                                <label class="form-label"> Amount *</label>
                                <input type="text" class="form-control test_form_input" id="ExpensesAmount">
                                <label class="form-label"> Date  *</label>
                                <input type="date" class="form-control test_form_input" id="ExpensesDate">
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button id="modal-close" class="btn modal_close_btn" data-bs-dismiss="modal" aria-label="Close">Close</button>
                    <button onclick="Save()" id="save-btn" style="width: auto;" class="btn" >Save</button>
                </div>
            </div>
    </div>
</div>




<script>
    async function Save() {
        try {
            let ExpensesName = document.getElementById('ExpensesName').value;
            let summernoteContent = $('#ExpensesNote').summernote('code');
            let ExpensesAmount = document.getElementById('ExpensesAmount').value;
            let ExpensesDate = document.getElementById('ExpensesDate').value;
            // let ExpensesCategorieID = document.getElementById('ExpensesCategorieID').value;

            if (ExpensesName.length === 0) {
                errorToast("Expenses Name Required !");
            }
            else if(summernoteContent.length === 0){
                errorToast("Expense Note Required !");
            }
            else if(ExpensesAmount.length === 0){
                errorToast("Expenses Amount Required !");
            }
            else if(ExpensesDate.length === 0){
                errorToast("Expenses Date Required !");
            }


            else {
                document.getElementById('modal-close').click();
                let formData = new FormData();
                formData.append('name', ExpensesName);
                formData.append('expense_note', summernoteContent);
                formData.append('amount', ExpensesAmount);
                formData.append('date', ExpensesDate);
                // formData.append('expenses_categories_id', ExpensesCategorieID);


                const config = {
                    headers: {
                        'content-type': 'multipart/form-data',
                        ...HeaderToken().headers
                    }
                }

                showLoader();
                let res = await axios.post("/create-expenses", formData, config);
                hideLoader();

                if (res.data['status'] === "success") {
                    successToast(res.data['message']);
                    document.getElementById("save-form").reset();
                    await getList();
                } else {
                    errorToast(res.data['message'])
                }
            }

        } catch (e) {
            unauthorized(e.response.status)
        }
    }

    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("ExpensesDate");
        flatpickr(inputField, {
            dateFormat: "Y-m-d",
            defaultDate: "today",
            onClose: function(selectedDates, dateStr, instance) {
                inputField.value = dateStr;
            }
        });
    });

</script>
<?php /**PATH C:\xampp\htdocs\DMS\resources\views/components/back-end/expenses/expenses-create.blade.php ENDPATH**/ ?>