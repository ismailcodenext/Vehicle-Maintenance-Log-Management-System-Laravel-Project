<div class="modal animated zoomIn"  id="create-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title" id="exampleModalLabel" style="font-size: 2em;">Create Expense Category</h6>
            </div>
            <div class="modal-body">
                <form id="save-form">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 p-1">
                                <label class="form-label" style="font-size: 18px;"> Expense Categories Name *</label>
                                <input type="text" class="form-control" style="height: 40px; background: #fff; color: #000; padding-left: 10px;" id="ExpensesCatagorie">
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button id="modal-close" class="btn modal_close_btn" data-bs-dismiss="modal" aria-label="Close">Close</button>
                    <button onclick="Save()" id="save-btn" class="btn" >Save</button>
                </div>
            </div>
    </div>
</div>

<script>
    async function Save() {
        try {
            let ExpensesCatagorie = document.getElementById('ExpensesCatagorie').value;

            if (ExpensesCatagorie.length === 0) {
                errorToast("Expenses Catagorie Required !");
            } else {
                document.getElementById('modal-close').click();
                let formData = new FormData();
                formData.append('category_name', ExpensesCatagorie);


                const config = {
                    headers: {
                        'content-type': 'multipart/form-data',
                        ...HeaderToken().headers
                    }
                }

                showLoader();
                let res = await axios.post("/create-expenses-categorie", formData, config);
                hideLoader();

                if (res.data['status'] === "success") {
                    successToast(res.data['message']);
                    document.getElementById("save-form").reset();
                    await getList();
                } else {
                    errorToast(res.data['message'])
                }
            }

        } catch (e) {
            unauthorized(e.response.status)
        }
    }
</script>
<?php /**PATH C:\xampp\htdocs\DMS\resources\views/components/back-end/expenses-categorie/expenses-categorie-create.blade.php ENDPATH**/ ?>