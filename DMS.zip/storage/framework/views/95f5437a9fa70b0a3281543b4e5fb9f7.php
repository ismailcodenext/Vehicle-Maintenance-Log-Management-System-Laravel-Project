<div class="container-fluid">
    <form id="save-form">
        <div class="row">
            <div class="col-md-12">
            <div class="card" style="margin: 20px auto ;">

            <div class="card-body test_add_card">

                <div class="row">
                    <div class="col-12">
                        <h2 class="text-center text-dark" style="font-size: 1.4em; font-weight: 600;">Patient Information</h2>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <label class="form-label">Patient Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control test_form_input" id="PatientName" required>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <label class="form-label">Mobile <span class="text-danger">*</span></label>
                        <input type="text" class="form-control test_form_input" id="Mobile">
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <label class="form-label">Email <span class="text-danger">*</span></label>
                        <input type="email" class="form-control test_form_input" id="Email">
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <label class="form-label">Address <span class="text-danger">*</span></label>
                        <input type="text" class="form-control test_form_input" id="Address">
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <label class="form-label">Date Of Birth <span class="text-danger">*</span></label>
                        <input type="date" class="form-control test_form_input" id="DateOfBirth">
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <label class="form-label">Gender <span class="text-danger">*</span></label>
                        <select class="form-select" id="Gender" aria-label="Default select example">
                            <option value="">Select Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <label class="form-label">Age <span class="text-danger">*</span></label>
                        <input type="text" class="form-control test_form_input" id="Age">
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <label class="form-label">Blood Group <span class="text-danger">*</span></label>
                        <input type="text" class="form-control test_form_input" id="BloodGroup">
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <label class="form-label">Doctor <span class="text-danger">*</span></label>
                        <select class="form-select" id="DoctorID" aria-label="Default select example">
                            <option value="">Select Doctor</option>
                        </select>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <label class="form-label">Referred Doctor <span class="text-danger">*</span></label>
                       <input type="text" class="form-control test_form_input" id="ReferredDoctorName" />
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <label class="form-label">PC ID <span class="text-danger">*</span></label>
                        <select class="js-example-basic-single form-control test_select" id="PCByID" aria-label="Default select example">
                            <option value="">Select PC</option>
                        </select>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <label class="form-label">PC/Reference Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control test_form_input" id="PCReferenceName" />
                    </div>
                </div>
            </div>


    </div>
    </div>
</div>



            <div class="form_wrapper" style="margin-bottom: 20px;">


                <h5 class="card-title text-center text-dark">Add Test</h5>

                <div class="form-row">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="row">
                                <div class="col-md-12">
                                    <label class="form-label">Select Test:</label>
                                    <select  class="js-example-basic-single form-control test_select" id="TestList" aria-label="Default select example">
                                        <option value="">Select Test</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-9">
                            <div class="row">
                                <div class="col-md-4">
                                    <label class="form-label">ID:</label>
                                    <input type="text"  class="form-control test_form_input" id="testID">
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label">Price:</label>
                                    <input type="text" class="form-control test_form_input" id="price">
                                </div>
                                <div class="col-md-4">
                                    <button type="button" onclick="addTest()" class="btn d-block w-100 test_btn">Add Test</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            <hr style="margin: 30px 0 15px; color: #332941;"/>

            

            <div class="row">

                        <div class="col-md-4">
                            <label>Invoice Date:</label>
                            <input class="form-control test_form_input" type="date" readonly class="bg-danger" id="InvoiceDate">
                        </div>
                        <div class="col-md-4">
                            <label>Report Delivery Date:</label>
                            <input class="form-control test_form_input" type="date" id="reportDeliveryDate" required>
                        </div>
                        <div class="col-md-4">
                            <label>Time:</label>
                            <input class="form-control test_form_input" type="time" id="reportDeliveryTime" required>
                        </div>

            </div>

            <div class="row">
                <div class="table-responsive">
                    <table class="test_table">
                        <thead>
                            <tr>
                                <th style="width: 10%">SL</th>
                                <th style="width: 25%">Test ID</th>
                                <th style="width: 30%">Test Name</th>
                                <th style="width: 30%">Amount</th>
                                <th style="width: 5%"></th>
                            </tr>
                        </thead>


                        <tbody id="testTableBody">
                        <!-- Add an id to tbody for easy manipulation -->
                        </tbody>

                        <tfoot >

                        <tr>
                            <td style="width: 10%"></td>
                            <td style="width: 25%"></td>
                            <td style="width: 30%" class="text-end">Sub Total:</td>
                            <td style="width: 30%"><span id="subTotal">0.00</span></td>
                            <td style="width: 5%"></td>
                        </tr>
                        <tr>
                            <td style="width: 10%"></td>
                            <td style="width: 25%"></td>
                            <td style="width: 30%" class="text-end">Discount?:</td>
                            <td style="width: 30%">
                                <select class="form-select" id="discountSelect">
                                    <option value="Amount">Amount</option>

                                </select>
                            </td>
                            <td style="width: 5%"></td>
                        </tr>
                        <tr>
                            <td style="width: 10%"></td>
                            <td style="width: 25%"></td>
                            <td style="width: 30%" class="text-end">Discount:</td>
                            <td style="width: 30%"><input type="number" id="discount" class="form-control test_form_input" value="0"></td>
                            <td style="width: 5%"></td>
                        </tr>
                        <tr>
                            <td style="width: 10%"></td>
                            <td style="width: 25%"></td>
                            <td style="width: 30%" class="text-end">Discount Amount:</td>
                            <td style="width: 30%"><span id="discountAmount">0</span></td>
                            <td style="width: 5%"></td>
                        </tr>
                        <tr>
                            <td style="width: 10%"></td>
                            <td style="width: 25%"></td>
                            <td style="width: 30%" class="text-end">PC Discount:</td>
                            <td style="width: 30%"><input type="number" id="PCDiscount" class="form-control test_form_input" value="0"></td>
                            <td style="width: 5%"></td>
                        </tr>
                        <tr>
                            <td style="width: 10%"></td>
                            <td style="width: 25%"></td>
                            <td style="width: 30%" class="text-end">Payment Status:</td>
                            <td style="width: 30%">
                                <select class="form-select" id="PaymentStatus">
                                    <option value="Full Paid">Full Paid</option>
                                    <option value="Due">Due</option>
                                    <option value="Partial Paid">Partial Paid</option>
                                </select>
                            </td>
                            <td style="width: 5%"></td>
                        </tr>
                        <tr>
                            <td style="width: 10%"></td>
                            <td style="width: 25%"></td>
                            <td style="width: 30%" class="text-end">Payment Method:</td>
                            <td style="width: 30%">
                                <select class="form-select" id="PaymentMethod">
                                    <option value="Cash">Cash</option>
                                    <option value="Bikash">Bikash</option>
                                    <option value="Nagad">Nagad</option>
                                </select>
                            </td>
                            <td style="width: 5%"></td>
                        </tr>
                        <tr>
                            <td style="width: 10%"></td>
                            <td style="width: 25%"></td>
                            <td style="width: 30%" class="text-end">Payment:</td>
                            <td style="width: 30%"><input type="number" id="PaidAmount" class="form-control test_form_input" value="0"></td>
                            <td style="width: 5%"></td>
                        </tr>
                        <tr>
                            <td style="width: 10%"></td>
                            <td style="width: 25%"></td>
                            <td style="width: 30%" class="text-end">Due Amount:</td>
                            <td style="width: 30%"><span id="dueAmount">0.00</span></td>
                            <td style="width: 5%"></td>
                        </tr>
                        </tfoot>
                        <input type="hidden" value="Active" id="InvoiceStatus">
                    </table>
                </div>
            </div>
            </div>
    </form>
    <div class="d-flex justify-content-end" style="margin-right: 0px;">
        <button onclick="Save()" id="save-btn" class="btn" style="margin-top: -5px; background: #fff; color: #000;">Submit</button>
    </div>

</div>


<script>
    // Get today's date
    var today = new Date();

    // Format the date as YYYY-MM-DD
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
    var yyyy = today.getFullYear();

    today = yyyy + '-' + mm + '-' + dd;

    // Set the value of the input element to today's date
    document.getElementById("InvoiceDate").value = today;
</script>

<script>
    FillDropDowns();
    FillPCNameDropDown();
    async function FillDropDowns() {
        try {
            let res = await axios.get("/list-doctor", HeaderToken());
            let doctors = res.data.doctor_data;
            let referrals = res.data.doctor_data;

            let optionsHtmlDoctors = doctors.map(doctor => `<option value="${doctor.id}">${doctor.name}</option>`)
                .join('');
            $("#DoctorID").html(optionsHtmlDoctors);

            let optionsHtmlReferrals = referrals.map(referral =>
                `<option value="${referral.id}">${referral.name}</option>`).join('');
            $("#ReferredByID").html(optionsHtmlReferrals);
        } catch (error) {
            console.error("Error occurred while fetching doctors and referrals:", error);
        }
    }


    async function FillPCNameDropDown() {
        try {
            let res = await axios.get("/list-pc", HeaderToken());
            let PCID = res.data.Pc_data;
            let optionsHtml = PCID.map(p_c_s => `<option value="${p_c_s.id}">${p_c_s.id}</option>`).join('');
            $("#PCByID").append(optionsHtml);
        } catch (error) {
            console.error("Error occurred while fetching test categories:", error);
        }
    }


    // Function to add a new test row to the table body
function addTest() {
    // Get the selected test name from the dropdown
    var testName = $('#TestList option:selected').text();

    // Get the price from the input field
    var price = $('#price').val();

    // Increment SL number based on the number of rows already present in the table
    var SL = $('#testTableBody tr').length + 1;
    var testId = $('#testID').val();

    // Call the addTestRow function with the captured data
    addTestRow(SL, testId, testName, price);
}

// Function to add a new test row to the table body
function addTestRow(sl, testId, testName, amount) {
    // Create a new table row
    var newRow = $('<tr>');

    // Add columns to the new row
    newRow.append('<td style="width: 10%;">' + sl + '</td>');
    newRow.append('<td style="width: 25%;">' + testId + '</td>');
    newRow.append('<td style="width: 30%;">' + testName + '</td>');
    newRow.append('<td style="width: 30%;">' + amount + '</td>');

    // Add a delete button to the row
    newRow.append('<td class="delete_row" style="width: 5%;"><i class="fa-solid fa-xmark delete-test-row" style="cursor: pointer;"></i></td>');

    // Append the new row to the table body
    $('#testTableBody').append(newRow);

    // Calculate subtotal after adding the new row
    calculateSubTotal();
}

// Event listener for delete button click
$(document).on('click', '.delete-test-row', function() {
    $(this).closest('tr').remove(); // Remove the row when delete button is clicked
    calculateSubTotal(); // Recalculate subtotal after deleting a row
});

// Event listener for add test button click
$('#addTestButton').click(function() {
    addTest(); // Call the addTest function when the button is clicked
});



    // =========================== Sub Total And DuaAmount Script Start==============================
    // Function to calculate subtotal
    function calculateSubTotal() {
        var subTotal = 0;

        // Iterate through each row and sum up the prices
        $('#testTableBody tr').each(function() {
            var priceText = $(this).find('td:nth-child(4)').text();
            var price = parseFloat(priceText);
            if (!isNaN(price)) {
                subTotal += price;
            }
        });

        // Update the subtotal display
        $('#subTotal').text(subTotal.toFixed(2));

        // Recalculate due amount whenever subtotal changes
        calculateDueAmount();
    }

    // Add input event listener to the discount input field
    $('#discount').on('input', function() {
        calculateDiscount();
    });

    // Function to calculate discount amount
    function calculateDiscount() {
        var subTotal = parseFloat($('#subTotal').text()); // Get subtotal value
        var discountType = $('#discountSelect').val(); // Get discount type (percentage or amount)
        var discountValue = parseFloat($('#discount').val()); // Get discount value

        if (discountType === 'Percentage') {
            var discountAmount = (subTotal * discountValue) / 100; // Calculate discount amount
        } else {
            var discountAmount = discountValue; // Use discount value as discount amount
        }

        // Update discount amount display
        $('#discountAmount').text(discountAmount.toFixed(2));

        // Recalculate due amount
        calculateDueAmount();
    }

    // Function to calculate due amount
    function calculateDueAmount() {
        var subTotal = parseFloat($('#subTotal').text()); // Get subtotal value
        var discountAmount = parseFloat($('#discountAmount').text()); // Get discount amount
        var paidAmount = parseFloat($('#PaidAmount').val()); // Get paid amount

        // Calculate due amount by subtracting discount and paid amount from subtotal
        var dueAmount = subTotal - discountAmount - paidAmount;

        // Update due amount display
        $('#dueAmount').text(dueAmount.toFixed(2));
    }

    // Add input event listener to the paid amount input field
    $('#PaidAmount').on('input', function() {
        calculateDueAmount();
    });

    // Trigger initial calculation when the page loads
    calculateSubTotal();

    // ======================== Sub Total And DuaAmount Script End==============================


    // Add change event listener to the discount select dropdown
    $('#discountSelect').change(function() {
        calculateDiscount();
    });

    // Add input event listener to the discount input field
    $('#discount').on('input', function() {
        calculateDiscount();
        calculateDueAmount(); // Call calculateDueAmount() whenever the discount changes
    });

    // // Add input event listener to the payment input field, if it exists
    // $('#payment').on('input', function() {
    //     calculateDueAmount();
    // });

    // Function to calculate discount amount
    function calculateDiscount() {
        var subTotal = parseFloat($('#subTotal').text()); // Get subtotal value
        var discountType = $('#discountSelect').val(); // Get discount type (percentage or amount)
        var discountValue = parseFloat($('#discount').val()); // Get discount value

        if (discountType === 'percentage') {
            var discountAmount = (subTotal * discountValue) / 100; // Calculate discount amount
        } else {
            var discountAmount = discountValue; // Use discount value as discount amount
        }

        // Update discount amount display
        $('#discountAmount').text(discountAmount.toFixed(2));

        // Recalculate due amount
        calculateDueAmount();
    }

    // Function to calculate due amount
    function calculateDueAmount() {
        var subTotal = parseFloat($('#subTotal').text()); // Get subtotal value
        var discountAmount = parseFloat($('#discountAmount').text()); // Get discount amount
        var payment = parseFloat($('#PaidAmount').val()); // Get payment amount

        // Check if payment value is valid
        if (isNaN(payment)) {
            payment = 0; // Set payment to zero if it's not a valid number
        }

        // Calculate due amount by subtracting discount and payment from subtotal
        var dueAmount = subTotal - discountAmount - payment;

        // Update due amount display
        $('#dueAmount').text(dueAmount.toFixed(2));
    }

    // Add input event listener to the payment input field, if it exists
    // $('#payment').on('input', function() {
    //     calculateDueAmount();
    // });

    // Add input event listener to the discount input field
    $('#discount').on('input', function() {
        calculateDiscount();
    });

    // Add change event listener to the discount select dropdown
    $('#discountSelect').change(function() {
        calculateDiscount();
    });



    FillClassNameDropDown();

    async function FillClassNameDropDown() {
        try {
            let res = await axios.get("/list-test", HeaderToken());
            let testList = res.data.Test_data;
            let optionsHtml = testList.map(test => `<option value="${test.id}">${test.test_name}</option>`).join(
                '');
            $("#TestList").append(optionsHtml);
        } catch (error) {
            console.error("Error occurred while fetching test categories:", error);
        }
    }

    $(document).ready(function() {
        // Add change event listener to the select dropdown
        $('#TestList').change(function() {
            var testId = $(this).val(); // Get the selected category ID
            if (testId) {
                // Get CSRF token from meta tag
                var csrfToken = $('meta[name="csrf-token"]').attr('content');

                // If a category is selected, make an AJAX request to fetch the corresponding test details
                $.ajax({
                    url: '/list-by-test',
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': csrfToken, // Include CSRF token in the headers
                        'Authorization': HeaderToken().headers
                            .Authorization // Include JWT token if needed
                    },
                    data: {
                        id: testId
                    },
                    success: function(response) {
                        if (response.status === 'success') {
                            // Update the price and referrer fee fields with the fetched values
                            $('#testID').val(response.tests.length > 0 ? response.tests[0]
                                .id : '');

                            $('#price').val(response.tests.length > 0 ? response.tests[0]
                                .price : '');
                            // $('#referrer-fee').val(response.tests.length > 0 ? response
                            //     .tests[0].commission : '');
                        } else {
                            // Handle error
                            console.error(response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            }
        });
    });



    async function Save() {
        try {


            let patientName = document.getElementById('PatientName').value;
            let Mobile = document.getElementById('Mobile').value;
            let Gender = document.getElementById('Gender').value;
            let Age = document.getElementById('Age').value;
            let DateOfBirth = document.getElementById('DateOfBirth').value;
            let BloodGroup = document.getElementById('BloodGroup').value;
            let Address = document.getElementById('Address').value;
            let Email = document.getElementById('Email').value;


            let DoctorID = document.getElementById('DoctorID').value;
            let ReferredDoctorName = document.getElementById('ReferredDoctorName').value;
            let PCReferenceName = document.getElementById('PCReferenceName').value;
            let PCDiscount = document.getElementById('PCDiscount').value;
            let InvoiceDate = document.getElementById('InvoiceDate').value;
            let reportDeliveryDate = document.getElementById('reportDeliveryDate').value;
            let reportDeliveryTime = document.getElementById('reportDeliveryTime').value;
            let subTotal = parseFloat(document.getElementById('subTotal').innerText); // Updated to parse float
            let discountSelect = document.getElementById('discountSelect').value;
            let discount = parseFloat(document.getElementById('discount').value); // Updated to parse float
            let PaymentStatus = document.getElementById('PaymentStatus').value;
            let PaymentMethod = document.getElementById('PaymentMethod').value;
            let PaidAmount = parseFloat(document.getElementById('PaidAmount').value); // Updated to parse float
            let PCByID = document.getElementById('PCByID').value;

            // Calculate due amount based on subtotal, discount, and paid amount
            let discountAmount = (discountSelect === 'Percentage') ? (subTotal * discount) / 100 : discount;
            let dueAmount = subTotal - discountAmount - PaidAmount;

            // Collect test details in start
            let tests = [];
            $('#testTableBody tr').each(function() {
                let testID = parseFloat($(this).find('td:nth-child(2)').text());
                let testName = $(this).find('td:nth-child(3)').text();
                let amount = parseFloat($(this).find('td:nth-child(4)').text());
                tests.push({ test_id: testID, test_name: testName, amount: amount }); // Include the test_id property
            });

            if (patientName.length === 0) {
                errorToast("Patient Name Required !");
            }

            else if (Mobile.length === 0) {
                errorToast("Patient Mobile Required !");

            }
            else if (Address.length === 0) {
                errorToast("Patient Address Required !");
            }

            else if (DateOfBirth.length === 0) {
                errorToast("Patient Date Of Birth Required !");
            }

            else if (Gender.length === 0) {
                errorToast("Patient Gender Required !");
            }

            else if (Age.length === 0) {
                errorToast("Patient Age Required !");
            }

            else if (reportDeliveryDate.length === 0) {
                errorToast("report Delivery Date Required !");
            }

            else if (reportDeliveryTime.length === 0) {
                errorToast("report Delivery Time Required !");
            }
            else if (reportDeliveryTime.length === 0) {
                errorToast("report Delivery Time Required !");
            }

            else if (PaidAmount.length === 0) {
                errorToast("report Delivery Time Required !");
            }
            else {
            let formData = new FormData();
            formData.append('patient_name', patientName);
            formData.append('mobile', Mobile);
            formData.append('gender', Gender);
            formData.append('age', Age);
            formData.append('dob', DateOfBirth);
            formData.append('blood_group', BloodGroup);
            formData.append('address', Address);
            formData.append('email', Email);
            formData.append('invoice_date', InvoiceDate);
            formData.append('report_delivery_date', reportDeliveryDate);
            formData.append('report_delivery_time', reportDeliveryTime);


            formData.append('pc_discount', PCDiscount);
            formData.append('referred_by_doctor', ReferredDoctorName);
            formData.append('pc_reference_name', PCReferenceName);
            formData.append('doctor_id', DoctorID);
            formData.append('subtotal', subTotal);
            formData.append('discount_ap', discountSelect);
            formData.append('discount_amount', discountAmount);
            formData.append('payment_status', PaymentStatus);
            formData.append('payment_method', PaymentMethod);
            formData.append('paid_amount', PaidAmount);
            formData.append('due_amount', dueAmount);

            formData.append('pc_id', PCByID);

            formData.append('tests', JSON.stringify(tests));

            const config = {
                headers: {
                    'content-type': 'multipart/form-data',
                    ...HeaderToken().headers
                }
            };

            showLoader();
            let res = await axios.post("/create-invoice", formData, config);
            hideLoader();

             if (res.data.status === "success") {
                 window.location.href = '/invoicePrint';
                 successToast(res.data.message);
                 document.getElementById("save-form").reset();
                 await getList();
             }else {
                errorToast(res.data.message);
            }
            }
        } catch (error) {
            if (error.response && error.response.status) {
                unauthorized(error.response.status);
            } else {
                console.error("Error occurred:", error);
            }
        }
    }



    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("DateOfBirth");
        flatpickr(inputField, {
            dateFormat: "Y-m-d",
            defaultDate: "today",
            onClose: function(selectedDates, dateStr, instance) {
                inputField.value = dateStr;
            }
        });
    });


    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("reportDeliveryDate");
        flatpickr(inputField, {
            dateFormat: "Y-m-d",
            defaultDate: "today",
            onClose: function(selectedDates, dateStr, instance) {
                inputField.value = dateStr;
            }
        });
    });

    //
    // function updateTime() {
    //     const timeInput = document.getElementById('reportDeliveryTimes');
    //     const now = new Date();
    //     let hours = now.getHours();
    //     let minutes = now.getMinutes();
    //
    //     // Format hours and minutes to always have two digits
    //     hours = hours < 10 ? '0' + hours : hours;
    //     minutes = minutes < 10 ? '0' + minutes : minutes;
    //
    //     timeInput.value = `${hours}:${minutes}`;
    // }
    //
    // // Initial call to set the time immediately
    // updateTime();
    //
    // // Update the time every minute
    // setInterval(updateTime, 60000);

</script>
<?php /**PATH C:\xampp\htdocs\DMS\resources\views/components/back-end/invoice/invoice-create.blade.php ENDPATH**/ ?>