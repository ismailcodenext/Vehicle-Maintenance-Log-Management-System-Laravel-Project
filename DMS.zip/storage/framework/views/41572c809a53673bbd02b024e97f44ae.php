<div class="modal animated zoomIn" id="update-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update PC Info</h5>
            </div>
            <div class="modal-body">
                <form id="update-form">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">

                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="form-label">PC Name *</label>
                                        <input type="text" class="form-control test_form_input" id="PCNameUpdate" >
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Mobile *</label>
                                <input type="text" class="form-control test_form_input" id="PCMobileUpdate" >
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Email *</label>
                                <input type="email" class="form-control test_form_input" id="PCEmailUpdate" >
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">NID Number *</label>
                                <input type="text" class="form-control test_form_input" id="PCNIDNumberUpdate" >
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Address *</label>
                                <input type="text" class="form-control test_form_input" id="AddressUpdate" >
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Age *</label>
                                <input type="number" class="form-control test_form_input" id="AgeUpdate" >
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Gender *</label>
                                <select class="form-select" id="GenderUpdate" aria-label="Default select example" >
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Status *</label>
                                <select class="form-select" id="StatusUpdate" aria-label="Default select example">
                                    <option value="">Select Status</option>
                                    <option value="Active">Active</option>
                                    <option value="Unactive">Unactive</option>
                                </select>
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Hospital *</label>
                                <input type="text" class="form-control test_form_input" id="HospitalUpdate">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Discount Percentage *</label>
                                <input type="number" class="form-control test_form_input" id="DiscountPercentageUpdate">
                                <input class="d-none" id="updateID">
                                    </div>

                                    <div class="col-md-6">
                                        <div class="d-flex align-items-center mt-3">
                                        <img class="w-25 me-3" id="oldImg" src="<?php echo e(asset('images/default.jpg')); ?>"/>
                                            <div>
                                            <label class="form-label mt-2">Image</label>
                                                <input oninput="updatePreview(this)" type="file" class="form-control pc_img_input" id="PCImageUpdate">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                               </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button id="update-modal-close" class="btn modal_close_btn" data-bs-dismiss="modal" aria-label="Close" style="margin: 0px 10px 0 0px;">Close</button>
                <button onclick="Update(event)" id="update-btn" class="btn modal_update_btn" style="width: auto; margin: 0px 0 0 0px;">Update</button>
            </div>
        </div>
    </div>
</div>

<script>
    async function updatePreview(input, imageUrl) {
        const oldImg = document.getElementById('oldImg');

        if (input.files && input.files[0]) {
            oldImg.src = window.URL.createObjectURL(input.files[0]);
        } else if (imageUrl) {
            oldImg.src = imageUrl;
        } else {
            oldImg.src = "<?php echo e(asset('images/default.jpg')); ?>";
        }
    }


    async function FillUpUpdateForm(id) {
        try {
            document.getElementById('updateID').value = id;
            showLoader();
            let res = await axios.post("/pc-by-id", { id: id.toString() }, HeaderToken());
            hideLoader();

            let data = res.data.rows;
            document.getElementById('PCNameUpdate').value = data.name;
            document.getElementById('PCMobileUpdate').value = data.mobile;
            document.getElementById('PCEmailUpdate').value = data.email;
            document.getElementById('PCNIDNumberUpdate').value = data.nid;
            document.getElementById('AddressUpdate').value = data.address;
            document.getElementById('AgeUpdate').value = data.age;
            document.getElementById('GenderUpdate').value = data.gender;
            document.getElementById('StatusUpdate').value = data.status;
            document.getElementById('HospitalUpdate').value = data.hospital;
            document.getElementById('DiscountPercentageUpdate').value = data.discount_percentage;

            // Update the preview with the existing image URL
            updatePreview(document.getElementById('PCImageUpdate'), data.img_url);
        } catch (e) {
            unauthorized(e.response.status);
        }
    }




    async function Update() {
        try {
            let PCNameUpdate = document.getElementById('PCNameUpdate').value;
            let PCMobileUpdate = document.getElementById('PCMobileUpdate').value;
            let PCEmailUpdate = document.getElementById('PCEmailUpdate').value;
            let PCNIDNumberUpdate = document.getElementById('PCNIDNumberUpdate').value;
            let AddressUpdate = document.getElementById('AddressUpdate').value;
            let AgeUpdate = document.getElementById('AgeUpdate').value;
            let GenderUpdate = document.getElementById('GenderUpdate').value;
            let StatusUpdate = document.getElementById('StatusUpdate').value;
            let HospitalUpdate = document.getElementById('HospitalUpdate').value;
            let DiscountPercentageUpdate = document.getElementById('DiscountPercentageUpdate').value;
            let updateID = document.getElementById('updateID').value;
            let PCImageUpdate = document.getElementById('PCImageUpdate').files[0];

            // if (!CastNameUpdate || !CasttitleUpdate || !CastViewLinkUpdate || !updateID) {
            //     errorToast("All fields are required!");
            //     return;
            // }

            document.getElementById('update-modal-close').click();

            let formData = new FormData();
            formData.append('name', PCNameUpdate);
            formData.append('mobile', PCMobileUpdate);
            formData.append('email', PCEmailUpdate);
            formData.append('nid', PCNIDNumberUpdate);
            formData.append('address', AddressUpdate);
            formData.append('age', AgeUpdate);
            formData.append('gender', GenderUpdate);
            formData.append('status', StatusUpdate);
            formData.append('hospital', HospitalUpdate);
            formData.append('discount_percentage', DiscountPercentageUpdate);
            formData.append('img', PCImageUpdate);
            formData.append('id', updateID);

            const config = {
                headers: {
                    'content-type': 'multipart/form-data',
                    ...HeaderToken().headers
                }
            };

            showLoader();

            let res = await axios.post("/update-pc", formData, config);
            hideLoader();

            if (res.data.status === "success") {
                successToast(res.data.message);
                let modal = new bootstrap.Modal(document.getElementById('update-modal'));
                modal.hide();
                await getList();
            } else {
                errorToast(res.data.message);
            }

        } catch (e) {
            unauthorized(e.response.status);
        }
    }
</script>
<?php /**PATH C:\xampp\htdocs\DMS\resources\views/components/back-end/pc/pc-update.blade.php ENDPATH**/ ?>