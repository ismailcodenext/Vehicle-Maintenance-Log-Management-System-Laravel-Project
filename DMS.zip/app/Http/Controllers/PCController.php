<?php

namespace App\Http\Controllers;

use App\Models\PC;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class PCController extends Controller
{
  public function PCList()
    {
        try {
            $user_id = Auth::id();
            $Pc_data = PC::get();
            return response()->json(['status' => 'success', 'Pc_data' => $Pc_data]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


    public function PCCreate(Request $request)
    {
        try {
            // Get authenticated user's ID
            $user_id = Auth::id();
            $img = $request->file('img');
            $t = time();
            $file_name = $img->getClientOriginalName();
            $img_name = "{$user_id}-{$t}-{$file_name}";
            $img_url = "uploads/pc-img/{$img_name}";
            $img->move(public_path('uploads/pc-img'), $img_name);
            // Create new Patient
            PC::create([
                'img_url' => $img_url,
                'name' => $request->input('name'),
                'mobile' => $request->input('mobile'),
                'email' => $request->input('email'),
                'nid' => $request->input('nid'),
                'address' => $request->input('address'),
                'age' => $request->input('age'),
                'gender' => $request->input('gender'),
                'status' => $request->input('status'),
                'hospital' => $request->input('hospital'),
                'discount_percentage' => $request->input('discount_percentage'),
                'user_id' => $user_id
            ]);
            return response()->json(['status' => 'success', 'message' => 'PC created successfully']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


    function PCByID(Request $request){
        try {
            $user_id = Auth::id();
            $request->validate(["id" => 'required|string']);

            $rows = PC::where('id', $request->input('id'))->where('user_id', $user_id)->first();
            return response()->json(['status' => 'success', 'rows' => $rows]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }



    function PCUpdate(Request $request)
    {
        try {
            $user_id = Auth::id();
            $PC_Update = PC::find($request->input('id'));

            if (!$PC_Update || $PC_Update->user_id != $user_id) {
                return response()->json(['status' => 'fail', 'message' => 'PC Page not found or unauthorized access.']);
            }

            // Update the cast information
            $PC_Update->name = $request->input('name');
            $PC_Update->mobile = $request->input('mobile');
            $PC_Update->email = $request->input('email');
            $PC_Update->nid = $request->input('nid');
            $PC_Update->address = $request->input('address');
            $PC_Update->age = $request->input('age');
            $PC_Update->gender = $request->input('gender');
            $PC_Update->status = $request->input('status');
            $PC_Update->hospital = $request->input('hospital');
            $PC_Update->discount_percentage = $request->input('discount_percentage');

            if ($request->hasFile('img')) {
                $img = $request->file('img');
                $t = time();
                $file_name = $img->getClientOriginalName();
                $img_name = "{$user_id}-{$t}-{$file_name}";
                $img_url = "uploads/pc-img/{$img_name}";

                // Upload File
                $img->move(public_path('uploads/pc-img'), $img_name);


                if ($PC_Update->img_url && file_exists(public_path($PC_Update->img_url))) {
                    unlink(public_path($PC_Update->img_url));
                }
                $PC_Update->img_url = $img_url;
            }

            $PC_Update->save();

            return response()->json(['status' => 'success', 'message' => 'PC Page Update Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }



    function PCDelete(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|string|min:1'
            ]);

            $PC_id = $request->input('id');
            $PC_delete = PC::find($PC_id);

            if (!$PC_delete) {
                return response()->json(['status' => 'fail', 'message' => 'Img not found.']);
            }

            if ($PC_delete->img_url && file_exists(public_path($PC_delete->img_url))) {
                unlink(public_path($PC_delete->img_url));
            }

            PC::where('id', $PC_id)->delete();

            return response()->json(['status' => 'success', 'message' => 'PC Permanent Delete Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }




}
