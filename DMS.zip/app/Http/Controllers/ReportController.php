<?php

namespace App\Http\Controllers;
use App\Models\Invoice;
use App\Models\Test;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ReportController extends Controller
{



//    public function AllSummeryReport()
//    {
//        $reportData = DB::table('invoice_details')
//            ->join('tests', 'invoice_details.test_id', '=', 'tests.id')
//            ->select(
//                DB::raw('DATE(invoice_details.created_at) as date'),
//                DB::raw('COUNT(tests.id) as total_count_tests'),
//                DB::raw('SUM(tests.price) as total_tests'),
//                DB::raw('SUM(CASE WHEN tests.department = "Pathology" THEN tests.price ELSE 0 END) as pathology_total'),
//                DB::raw('SUM(CASE WHEN tests.department = "Ultrasound" THEN tests.price ELSE 0 END) as ultrasound_total'),
//                DB::raw('SUM(CASE WHEN tests.department = "Hormone" THEN tests.price ELSE 0 END) as hormone_total'),
//                DB::raw('SUM(CASE WHEN tests.department = "ECG" THEN tests.price ELSE 0 END) as ecg_total'),
//            )
//            ->groupBy(DB::raw('DATE(invoice_details.created_at)'))
//            ->get();
//
//        $discountAmounts = DB::table('invoices')
//            ->select(DB::raw('DATE(invoice_date) AS date'), DB::raw('SUM(discount_amount) AS total_discount_amount'))
//            ->groupBy(DB::raw('DATE(invoice_date)'))
//            ->get();
//
//        // Merge report data with discount amounts
//        foreach ($reportData as $key => $report) {
//            foreach ($discountAmounts as $discount) {
//                if ($report->date == $discount->date) {
//                    $reportData[$key]->total_discount_amount = $discount->total_discount_amount;
//                }
//            }
//        }
//
//        return response()->json(['status' => 'success', 'reportData' => $reportData]);
//    }

//    public function AllSummeryReport()
//    {
//        $reportData = DB::table('invoice_details')
//            ->join('tests', 'invoice_details.test_id', '=', 'tests.id')
//            ->select(
//                DB::raw('DATE(invoice_details.created_at) as date'),
//                DB::raw('COUNT(tests.id) as total_count_tests'),
//                DB::raw('SUM(tests.price) as total_tests'),
//                DB::raw('SUM(CASE WHEN tests.department = "Pathology" THEN tests.price ELSE 0 END) as pathology_total'),
//                DB::raw('SUM(CASE WHEN tests.department = "Ultrasound" THEN tests.price ELSE 0 END) as ultrasound_total'),
//                DB::raw('SUM(CASE WHEN tests.department = "Hormone" THEN tests.price ELSE 0 END) as hormone_total'),
//                DB::raw('SUM(CASE WHEN tests.department = "ECG" THEN tests.price ELSE 0 END) as ecg_total'),
//            )
//            ->groupBy(DB::raw('DATE(invoice_details.created_at)'))
//            ->get();
//
//        $discountAmounts = DB::table('invoices')
//            ->select(DB::raw('DATE(invoice_date) AS date'), DB::raw('SUM(discount_amount) AS total_discount_amount'))
//            ->groupBy(DB::raw('DATE(invoice_date)'))
//            ->get();
//
//        $paidAmounts = DB::table('invoices')
//            ->select(DB::raw('DATE(invoice_date) AS date'), DB::raw('SUM(paid_amount) AS total_paid_amount'))
//            ->groupBy(DB::raw('DATE(invoice_date)'))
//            ->get();
//
//        $expenseData = DB::table('expenses')
//            ->select(
//                DB::raw('SUM(CASE WHEN expenses.name = "Sonologist Payment" THEN expenses.amount ELSE 0 END) as sonologist_total'),
//            )
//            ->groupBy(DB::raw('DATE(expenses.created_at)'))
//            ->get();
//
//
//
//        // Merge report data with discount amounts and paid amounts
//        foreach ($reportData as $key => $report) {
//            foreach ($discountAmounts as $discount) {
//                if ($report->date == $discount->date) {
//                    $reportData[$key]->total_discount_amount = $discount->total_discount_amount;
//                }
//            }
//            foreach ($paidAmounts as $paid) {
//                if ($report->date == $paid->date) {
//                    $reportData[$key]->total_paid_amount = $paid->total_paid_amount;
//                }
//            }
//
//            foreach ($expenseData as $expense) {
//                if ($report->date == $expense->date) {
//                    $reportData[$key]->sonologist_total = $expense->sonologist_total;
//                }
//            }
//
//
//
//
//
//        }
//
//        return response()->json(['status' => 'success', 'reportData' => $reportData]);
//    }


    public function AllSummeryReport(Request $request)
    {
        $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');
        $reportData = DB::table('invoice_details')
            ->join('tests', 'invoice_details.test_id', '=', 'tests.id')
            ->select(
                DB::raw('DATE(invoice_details.created_at) as date'),
                DB::raw('COUNT(tests.id) as total_count_tests'),
                DB::raw('SUM(tests.price) as total_tests'),
                DB::raw('SUM(CASE WHEN tests.department = "Pathology" THEN tests.price ELSE 0 END) as pathology_total'),
                DB::raw('SUM(CASE WHEN tests.department = "Ultrasound" THEN tests.price ELSE 0 END) as ultrasound_total'),
                DB::raw('SUM(CASE WHEN tests.department = "Hormone" THEN tests.price ELSE 0 END) as hormone_total'),
                DB::raw('SUM(CASE WHEN tests.department = "ECG" THEN tests.price ELSE 0 END) as ecg_total'),
            )
            ->whereBetween(DB::raw('DATE(invoice_details.created_at)'), [$startDate, $endDate])
            ->groupBy(DB::raw('DATE(invoice_details.created_at)'))
            ->get();

        $discountAmounts = DB::table('invoices')
            ->select(DB::raw('DATE(invoice_date) AS date'), DB::raw('SUM(discount_amount) AS total_discount_amount'))
            ->groupBy(DB::raw('DATE(invoice_date)'))
            ->get();

        $paidAmounts = DB::table('invoices')
            ->select(DB::raw('DATE(invoice_date) AS date'), DB::raw('SUM(paid_amount) AS total_paid_amount'))
            ->groupBy(DB::raw('DATE(invoice_date)'))
            ->get();

        $expenseData = DB::table('expenses')
            ->select(
                DB::raw('DATE(expenses.created_at) as date'),
                DB::raw('SUM(CASE WHEN expenses.name = "Sonologist Payment" THEN expenses.amount ELSE 0 END) as sonologist_total'),
                DB::raw('SUM(CASE WHEN expenses.name = "PC Commission" THEN expenses.amount ELSE 0 END) as pc_commission_total'),
                DB::raw('SUM(CASE WHEN expenses.name = "Others Expense" THEN expenses.amount ELSE 0 END) as others_expense_total')
            )
            ->groupBy(DB::raw('DATE(expenses.created_at)'))
            ->get();



        // Merge report data with discount amounts, paid amounts, and expense data
        foreach ($reportData as $key => $report) {
            foreach ($discountAmounts as $discount) {
                if ($report->date == $discount->date) {
                    $reportData[$key]->total_discount_amount = $discount->total_discount_amount;
                }
            }
            foreach ($paidAmounts as $paid) {
                if ($report->date == $paid->date) {
                    $reportData[$key]->total_paid_amount = $paid->total_paid_amount;
                }
            }
            foreach ($expenseData as $expense) {
                if ($report->date == $expense->date) {
                    $reportData[$key]->sonologist_total = $expense->sonologist_total;
                    $reportData[$key]->pc_commission_total = $expense->pc_commission_total;
                    $reportData[$key]->others_expense_total = $expense->others_expense_total;
                }
            }
        }


        return response()->json(['status' => 'success', 'reportData' => $reportData]);
    }












}
