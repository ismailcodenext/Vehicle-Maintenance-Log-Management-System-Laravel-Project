<?php

namespace App\Http\Controllers;

use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\View;

class RoleController extends Controller
{
    public function PermissionList(){
        try {
            $Permission_data = Permission::all();
            return response()->json(['status' => 'success', 'Permission_data' => $Permission_data]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    public function PermissionCreate(Request $request){
        try {
            Permission::create([
                'name' => $request->input('name'),
                'group_name' => $request->input('group_name'),
            ]);
            return response()->json(['status' => 'success', 'message' => 'Permission Create Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    public function PermissionById(Request $request){
        try {
//            $user_id = Auth::id();
//            $request->validate(["id" => 'required|string']);

            $rows = Permission::where('id', $request->input('id'))->first();
            return response()->json(['status' => 'success', 'rows' => $rows]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    public function PermissionUpdate(Request $request){
        try {
            $Permission_Update = Permission::find($request->input('id'));

//            if (!$TestCategory_Update || $TestCategory_Update->user_id != $user_id) {
//                return response()->json(['status' => 'fail', 'message' => 'Category Name not found or unauthorized access.']);
//            }
            $Permission_Update->name = $request->input('name');
            $Permission_Update->group_name = $request->input('group_name');
            $Permission_Update->save();

            return response()->json(['status' => 'success', 'message' => 'Permission Update Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    public function RolesList(){
        try {
            $Roles_data = Role::all();
            return response()->json(['status' => 'success', 'Roles_data' => $Roles_data]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }
    public function RolesCreate(Request $request){
        try {
            Role::create([
                'name' => $request->input('name'),
            ]);
            return response()->json(['status' => 'success', 'message' => 'Roles Create Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    public function RoleInPermissionCreate(){
//        try {
//            $Roles_data = Role::all();
//            $Permission_data = Permission::all();
//            return response()->json(['status' => 'success', 'Roles_data' => $Roles_data, 'Permission_data' => $Permission_data]);
//        } catch (Exception $e) {
//            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
//        }
        $roles = Role::all();
        $permissions = Permission::all();
        $permission_groups = User::getpermissionGroups();
        return view('pages.back-end-page.role-in-permission-test-page',compact('roles','permissions','permission_groups'));
    }

    public function RoleInPermissionStore(Request $request){
        $data = array();
        $permissions = $request->permission;

        foreach($permissions as $key => $item){
            $data['role_id'] = $request->role_id;
            $data['permission_id'] = $item;

            DB::table('role_has_permissions')->insert($data);

        }

        $notification = array(
            'message' => 'Role Permission Added Successfully',
            'alert-type' => 'success'
        );

        return redirect()->route('list.role.in.permission')->with($notification);

    }// End Method

    public function RoleInPermissionList(){
        $roles = Role::all();
        return view('pages.back-end-page.role-in-permission-list-page',compact('roles'));
    }

    public function RoleInPermissionEdit($id){
        $role = Role::findOrFail($id);
        $permissions = Permission::all();
        $permission_groups = User::getpermissionGroups();
        return view('pages.back-end-page.role-in-permission-edit-page',compact('role','permissions','permission_groups'));
    }

    public function RoleInPermissionUpdate(Request $request,$id){
        $role = Role::findOrFail($id);
        $permissionIDs = $request->permission;

        // Assuming you have a Permission model with a method to fetch names from IDs
        $permissions = Permission::whereIn('id', $permissionIDs)->pluck('name')->toArray();

        if (!empty($permissions)) {
            $role->syncPermissions($permissions);
        }

        $notification = array(
            'message' => 'Role Permission Updated Successfully',
            'alert-type' => 'success'
        );

        return redirect()->route('list.role.in.permission')->with($notification);

    }// End Method

    public function RoleInPermissionDelete($id){

        try {
            // Delete the role from the roles table
            DB::table('roles')->where('id', $id)->delete();

            $notification = [
                'message' => 'Role Permission Deleted Successfully',
                'alert-type' => 'success'
            ];

            return redirect()->back()->with($notification);
        } catch (\Exception $e) {
            $notification = [
                'message' => 'Error deleting role: ' . $e->getMessage(),
                'alert-type' => 'error'
            ];

            return redirect()->back()->with($notification);
        }
    } // End Method


}
