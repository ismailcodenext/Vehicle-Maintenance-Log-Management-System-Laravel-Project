<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Patient;
use App\Models\Doctor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class PatientController extends Controller
{


    function PatientList()
    {
        try {

            $Patient_data = Patient::get();
            return response()->json(['status' => 'success', 'Patient_data' => $Patient_data]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    public function PatientCreate(Request $request)
    {
        try {
            // Get authenticated user's ID
            $user_id = Auth::id();

            // Create new Patient
            Patient::create([
                'patient_name' => $request->input('patient_name'),
                'mobile' => $request->input('mobile'),
                'gender' => $request->input('gender'),
                'age' => $request->input('age'),
                'dob' => $request->input('dob'),
                'blood_group' => $request->input('blood_group'),
                'address' => $request->input('address'),
                'email' => $request->input('email'),
                'doctor_id' => $request->input('doctor_id'),
                'referred_by_id' => $request->input('referred_by_id'),
                'user_id' => $user_id
            ]);

            return response()->json(['status' => 'success', 'message' => 'Patient created successfully']);
        } catch (Exception $e) {
            // Handle exceptions
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }
    function PatientById(Request $request){
        try {
            $user_id = Auth::id();
            $request->validate(["id" => 'required|string']);

            $rows = Patient::where('id', $request->input('id'))->where('user_id', $user_id)->first();
            return response()->json(['status' => 'success', 'rows' => $rows]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


    function PatientUpdate(Request $request)
    {
        try {
            $user_id = Auth::id();
            $Patient_Update = Patient::find($request->input('id'));

            if (!$Patient_Update || $Patient_Update->user_id != $user_id) {
                return response()->json(['status' => 'fail', 'message' => 'Patient not found or unauthorized access.']);
            }
            $Patient_Update->patient_name = $request->input('patient_name');
            $Patient_Update->mobile = $request->input('mobile');
            $Patient_Update->gender = $request->input('gender');
            $Patient_Update->age = $request->input('age');
            $Patient_Update->dob = $request->input('dob');
            $Patient_Update->blood_group = $request->input('blood_group');
            $Patient_Update->address = $request->input('address');
            $Patient_Update->email = $request->input('email');
            $Patient_Update->doctor_id = $request->input('doctor_id');
            $Patient_Update->referred_by_id = $request->input('referred_by_id');
            $Patient_Update->save();

            return response()->json(['status' => 'success', 'message' => 'Patient Update Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }



    function PatientDelete(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|string|min:1'
            ]);
            $Patient_Delete_id = $request->input('id');
            $LaboHemeSale_Delete = Patient::find($Patient_Delete_id);

            if (!$LaboHemeSale_Delete) {
                return response()->json(['status' => 'fail', 'message' => 'Patient not found.']);
            }
            Patient::where('id', $Patient_Delete_id)->delete();

            return response()->json(['status' => 'success', 'message' => 'Patient Delete Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    public function search(Request $request)
    {
        $patientId = $request->input('id');

        // Fetch patient data based on the provided ID
        $patient = Patient::find($patientId);

        if ($patient) {
            return response()->json([
                'status' => 'success',
                'patient' => $patient
            ]);
        } else {
            return response()->json([
                'status' => 'error',
                'message' => 'Patient not found'
            ], 404); // Return 404 status code for not found
        }
    }
}
