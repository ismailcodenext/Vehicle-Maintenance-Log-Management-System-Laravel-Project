<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OLDPatientController extends Controller
{
    //
}
