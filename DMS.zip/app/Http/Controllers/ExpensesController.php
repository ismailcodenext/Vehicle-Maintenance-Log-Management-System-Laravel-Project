<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use App\Models\Expenses;

use Illuminate\Support\Facades\Auth;

class ExpensesController extends Controller
{
    function ExpensesList()
    {
        try {
            $user_id = Auth::id();
            $expenses_data = Expenses::with('category')->get();
            return response()->json(['status' => 'success', 'expenses_data' => $expenses_data]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }
    public function ExpensesDateWise(Request $request){
        try {
            $user_id = Auth::id();
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');

            // Query to fetch expenses data within the specified date range for the authenticated user
            $expensesReportData = Expenses::with('category')
                ->whereBetween('date', [$startDate, $endDate])
                ->get();

            return response()->json([
                'status' => 'success',
                'Expenses_Report_Data' => $expensesReportData
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'fail',
                'message' => $e->getMessage()
            ], 500);
        }
    }


    public function ExpensesCreate(Request $request)
    {
        try {
            $user_id = Auth::id();
            Expenses::create([
                'name' => $request->input ('name'),
                'expense_note' => $request->input ('expense_note'),
                'amount' => $request->input ('amount'),
                'date' => $request->input ('date'),
                'user_id' => $user_id
            ]);
            return response()->json(['status' => 'success', 'message' => 'Expenses Create Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    function ExpensesById(Request $request){
        try {
            $user_id = Auth::id();
            $request->validate(["id" => 'required|string']);

            $rows = Expenses::where('id', $request->input('id'))->where('user_id', $user_id)->first();
            return response()->json(['status' => 'success', 'rows' => $rows]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


    function ExpensesUpdate(Request $request)
    {
        try {
            $user_id = Auth::id();
            $Expenses_Update = Expenses::find($request->input('id'));

            if (!$Expenses_Update || $Expenses_Update->user_id != $user_id) {
                return response()->json(['status' => 'fail', 'message' => 'Expenses not found or unauthorized access.']);
            }
            $Expenses_Update->name = $request->input('name');
            $Expenses_Update->amount = $request->input('amount');
            $Expenses_Update->expense_note = $request->input('expense_note');
            $Expenses_Update->date = $request->input('date');
            $Expenses_Update->save();
            return response()->json(['status' => 'success', 'message' => 'Expenses  Update Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    function ExpensesDelete(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|string|min:1'
            ]);
            $Expenses_id = $request->input('id');
            $Expenses_Delete = Expenses::find($Expenses_id);

            if (!$Expenses_Delete) {
                return response()->json(['status' => 'fail', 'message' => 'Expenses Name not found.']);
            }
            Expenses::where('id', $Expenses_id)->delete();

            return response()->json(['status' => 'success', 'message' => 'Expenses Delete Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }
}
