<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use App\Models\ExpensesCategory;
use Illuminate\Support\Facades\Auth;

class ExpensesCategoryController extends Controller
{

    function ExpensesCategorieList()
    {
        try {
            $user_id = Auth::id();
            $ExpensesCategorie_data = ExpensesCategory::get();
            return response()->json(['status' => 'success', 'ExpensesCategorie_data' => $ExpensesCategorie_data]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


    public function ExpensesCategorieCreate(Request $request)
    {

        try {
            $user_id = Auth::id();

            ExpensesCategory::create([
                'category_name' => $request->input ('category_name'),
                'user_id' => $user_id
            ]);
            return response()->json(['status' => 'success', 'message' => 'Expenses Category Create Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    function ExpensesCategorieById(Request $request){
        try {
            $user_id = Auth::id();
            $request->validate(["id" => 'required|string']);

            $rows = ExpensesCategory::where('id', $request->input('id'))->where('user_id', $user_id)->first();
            return response()->json(['status' => 'success', 'rows' => $rows]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


    function ExpensesCategorieUpdate(Request $request)
    {
        try {
            $user_id = Auth::id();
            $ExpensesCategory_Update = ExpensesCategory::find($request->input('id'));

            if (!$ExpensesCategory_Update || $ExpensesCategory_Update->user_id != $user_id) {
                return response()->json(['status' => 'fail', 'message' => 'Category Name not found or unauthorized access.']);
            }
            $ExpensesCategory_Update->category_name = $request->input('category_name');
            $ExpensesCategory_Update->save();

            return response()->json(['status' => 'success', 'message' => 'Expenses Category Update Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }



    function ExpensesCategorieDelete(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|string|min:1'
            ]);
            $ExpensesCategory_id = $request->input('id');
            $ExpensesCategory_Delete = ExpensesCategory::find($ExpensesCategory_id);

            if (!$ExpensesCategory_Delete) {
                return response()->json(['status' => 'fail', 'message' => 'Category Name not found.']);
            }
            ExpensesCategory::where('id', $ExpensesCategory_id)->delete();

            return response()->json(['status' => 'success', 'message' => 'Expenses Category Delete Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

}
