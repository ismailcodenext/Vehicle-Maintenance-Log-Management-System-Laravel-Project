<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Doctor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DoctorController extends Controller
{
    public function DoctorList(){
        try {
            $user_id = Auth::id();
            $doctor_data = Doctor::get();
            return response()->json(['status' => 'success', 'doctor_data' => $doctor_data]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


    public function DoctorCreate(Request $request)
    {
        try {
            $user_id = Auth::id();
            $img = $request->file('img');
            $t = time();
            $file_name = $img->getClientOriginalName();
            $img_name = "{$user_id}-{$t}-{$file_name}";
            $img_url = "uploads/doctor-img/{$img_name}";
            $img->move(public_path('uploads/doctor-img'), $img_name);

            Doctor::create([
                'img_url' => $img_url,
                'name' => $request->input('name'),
                'email' => $request->input('email'),
                'specialization' => $request->input('specialization'),
                'degree' => $request->input('degree'),
                'mobile' => $request->input('mobile'),
                'hospital' => $request->input('hospital'),
                'chamber_address' => $request->input('chamber_address'),
                'registration_number' => $request->input('registration_number'),
                'user_id' => $user_id
            ]);
            return response()->json(['status' => 'success', 'message' => 'Doctor Create Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    function DoctorByUpdate(Request $request){
        try {
            $user_id = Auth::id();
            $request->validate(["id" => 'required|string']);

            $rows = Doctor::where('id', $request->input('id'))->where('user_id', $user_id)->first();
            return response()->json(['status' => 'success', 'rows' => $rows]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    function DoctorUpdate(Request $request)
    {
        try {
            $user_id = Auth::id();
            $DoctorData_Update = Doctor::find($request->input('id'));

            if (!$DoctorData_Update || $DoctorData_Update->user_id != $user_id) {
                return response()->json(['status' => 'fail', 'message' => 'Doctor Page not found or unauthorized access.']);
            }

            // Update the cast information
            $DoctorData_Update->email = $request->input('email');
            $DoctorData_Update->chamber_address = $request->input('chamber_address');
            $DoctorData_Update->name = $request->input('name');
            $DoctorData_Update->specialization = $request->input('specialization');
            $DoctorData_Update->degree = $request->input('degree');
            $DoctorData_Update->hospital = $request->input('hospital');
            $DoctorData_Update->mobile = $request->input('mobile');
            $DoctorData_Update->registration_number = $request->input('registration_number');

            if ($request->hasFile('img')) {
                $img = $request->file('img');
                $t = time();
                $file_name = $img->getClientOriginalName();
                $img_name = "{$user_id}-{$t}-{$file_name}";
                $img_url = "uploads/doctor-img/{$img_name}";

                // Upload File
                $img->move(public_path('uploads/doctor-img'), $img_name);


                if ($DoctorData_Update->img_url && file_exists(public_path($DoctorData_Update->img_url))) {
                    unlink(public_path($DoctorData_Update->img_url));
                }
                $DoctorData_Update->img_url = $img_url;
            }


            $DoctorData_Update->save();

            return response()->json(['status' => 'success', 'message' => 'Doctor Update Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    function DoctorDelete(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|string|min:1'
            ]);

            $doctor_id = $request->input('id');
            $doctor_delete = Doctor::find($doctor_id);

            if (!$doctor_delete) {
                return response()->json(['status' => 'fail', 'message' => 'doctor not found.']);
            }

            if ($doctor_delete->img_url && file_exists(public_path($doctor_delete->img_url))) {
                unlink(public_path($doctor_delete->img_url));
            }

            Doctor::where('id', $doctor_id)->delete();

            return response()->json(['status' => 'success', 'message' => 'Doctor Info Delete Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }



}
