<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;

class AdminController extends Controller
{
   public function AdminList(){
       $alladminuser = User::latest()->get();
       return view('pages.back-end-page.admin.list-admin',compact('alladminuser'));
   }// End Method

    public function AdminCreate(){
        $roles = Role::all();
        return view('pages.back-end-page.admin.create-admin',compact('roles'));
    }// End Method

    public function AdminStore(Request $request){
        $user = new User();
        $user->firstName = $request->firstName;
        $user->lastName = $request->lastName;
        $user->email = $request->email;
        $user->mobile = $request->phone;
        $user->password = Hash::make($request->password);
        $user->save();

        if ($request->roles) {
            // Ensure $request->roles is an array
            $roleIds = is_array($request->roles) ? $request->roles : [$request->roles];

            // Fetch roles from the 'sanctum' guard
            $roles = Role::where('guard_name', 'sanctum')
                ->whereIn('id', $roleIds)
                ->get();

            // Assign each role to the user
            foreach ($roles as $role) {
                $user->assignRole($role, 'sanctum');
            }
        }

        $notification = [
            'message' => 'New Admin User Created Successfully',
            'alert-type' => 'success'
        ];

        return redirect()->route('all.admin')->with($notification);
    }// End Method
}
