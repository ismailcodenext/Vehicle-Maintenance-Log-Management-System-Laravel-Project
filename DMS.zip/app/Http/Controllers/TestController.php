<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\Test;
use App\Models\TestCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class TestController extends Controller
{



    function TestList()
    {
        try {
            $user_id = Auth::id();
            $Test_data = Test::get();
            return response()->json(['status' => 'success', 'Test_data' => $Test_data]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    public function TestCreate(Request $request)
    {
        try {
            // Get authenticated user's ID
            $user_id = Auth::id();

            // Create new test
            Test::create([
                'test_name' => $request->input('test_name'),
                'department' => $request->input('department'),
                'price' => $request->input('price'),
                'commission' => $request->input('commission'),
                'status' => $request->input('status') ?? 'Active',
                'test_category_id' => $request->input('test_category_id'),
                'user_id' => $user_id
            ]);

            return response()->json(['status' => 'success', 'message' => 'Test created successfully']);
        } catch (Exception $e) {
            // Handle exceptions
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }
    function TestById(Request $request){
        try {
            $user_id = Auth::id();
            $request->validate(["id" => 'required|string']);

            $rows = Test::where('id', $request->input('id'))->where('user_id', $user_id)->first();
            return response()->json(['status' => 'success', 'rows' => $rows]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


    function TestUpdate(Request $request)
    {
        try {
            $user_id = Auth::id();
            $Test_Update = Test::find($request->input('id'));

            if (!$Test_Update || $Test_Update->user_id != $user_id) {
                return response()->json(['status' => 'fail', 'message' => 'Test not found or unauthorized access.']);
            }
            $Test_Update->test_name = $request->input('test_name');
            $Test_Update->price = $request->input('price');
            $Test_Update->commission = $request->input('commission');
            $Test_Update->status = $request->input('status');
            $Test_Update->test_category_id = $request->input('test_category_id');
            $Test_Update->save();

            return response()->json(['status' => 'success', 'message' => 'Test Update Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }



    function TestDelete(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|string|min:1'
            ]);
            $Test_Delete_id = $request->input('id');
            $LaboHemeSale_Delete = Test::find($Test_Delete_id);

            if (!$LaboHemeSale_Delete) {
                return response()->json(['status' => 'fail', 'message' => 'Test not found.']);
            }
            Test::where('id', $Test_Delete_id)->delete();

            return response()->json(['status' => 'success', 'message' => 'Test Delete Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }
    public function listByTest(Request $request){
        try {
            // Retrieve the category ID from the request
            $testId = $request->input('id');

            // Fetch test details based on the category ID
            $tests = Test::where('id', $testId)->get();

            // Prepare the response data
            if ($tests->isEmpty()) {
                // If no tests found, return an empty array for tests
                $responseData = [
                    'status' => 'success',
                    'tests' => []
                ];
            } else {
                // If tests found, return the tests array
                $responseData = [
                    'status' => 'success',
                    'tests' => $tests->toArray() // Convert test objects to array
                ];
            }

            // Return the response
            return response()->json($responseData);
        } catch (Exception $e) {
            // Handle exceptions
            return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    public function TestReport()
    {
        try {
            $tests = Test::all();

            // Fetch test data along with related invoice details
            $testReportData = Test::leftJoin('invoice_details', 'tests.id', '=', 'invoice_details.test_id')
                ->select('tests.id as test_id', 'tests.test_name', 'tests.price as unit_price',
                    DB::raw('count(invoice_details.id) as test_quantity'), // Use \DB::raw()
                    DB::raw('SUM(tests.price) as total_price')) // Use \DB::raw()
                ->groupBy('tests.id', 'tests.test_name', 'tests.price')
                ->get();
            return response()->json(['status' => 'success', 'testReportData' => $testReportData]);
        } catch (\Exception $e) { // Corrected Exception class
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    public function DateWiseTestReport(Request $request){
        try {
            $tests = Test::all();

            // Fetch test data along with related invoice details
            $query = Test::leftJoin('invoice_details', 'tests.id', '=', 'invoice_details.test_id')
                ->select('tests.id as test_id', 'tests.test_name', 'tests.price as unit_price',
                    DB::raw('count(invoice_details.id) as test_quantity'),
                    DB::raw('SUM(tests.price) as total_price'))
                ->groupBy('tests.id', 'tests.test_name', 'tests.price');

            // Filter by date range if provided
            if ($request->has('start_date') && $request->has('end_date')) {
                $startDate = $request->input('start_date');
                $endDate = $request->input('end_date');
                $query->whereBetween('invoice_details.created_at', [$startDate, $endDate]);
            }

            $testReportData = $query->get();

            return response()->json(['status' => 'success', 'testReportData' => $testReportData]);
        } catch (\Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }



}
