<?php

namespace App\Http\Controllers;

use Exception;
use App\Models\TestCategory;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;

class TestCategoryController extends Controller
{



    function TestCategorieList()
    {
        try {
            $user_id = Auth::id();
            $TestCategorie_data = TestCategory::get();
            return response()->json(['status' => 'success', 'TestCategorie_data' => $TestCategorie_data]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


    public function TestCategorieCreate(Request $request)
    {

        try {
            $user_id = Auth::id();

            TestCategory::create([
                'category_name' => $request->input ('category_name'),
                'user_id' => $user_id
            ]);
            return response()->json(['status' => 'success', 'message' => 'Test Category Create Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    function TestCategorieById(Request $request){
        try {
            $user_id = Auth::id();
            $request->validate(["id" => 'required|string']);

            $rows = TestCategory::where('id', $request->input('id'))->where('user_id', $user_id)->first();
            return response()->json(['status' => 'success', 'rows' => $rows]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


    function TestCategorieUpdate(Request $request)
    {
        try {
            $user_id = Auth::id();
            $TestCategory_Update = TestCategory::find($request->input('id'));

            if (!$TestCategory_Update || $TestCategory_Update->user_id != $user_id) {
                return response()->json(['status' => 'fail', 'message' => 'Category Name not found or unauthorized access.']);
            }
            $TestCategory_Update->category_name = $request->input('category_name');
            $TestCategory_Update->save();

            return response()->json(['status' => 'success', 'message' => 'Test Category Update Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }



    function TestCategorieDelete(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|string|min:1'
            ]);
            $TestCategory_id = $request->input('id');
            $TestCategory_Delete = TestCategory::find($TestCategory_id);

            if (!$TestCategory_Delete) {
                return response()->json(['status' => 'fail', 'message' => 'Category Name not found.']);
            }
            TestCategory::where('id', $TestCategory_id)->delete();

            return response()->json(['status' => 'success', 'message' => 'Test Category Delete Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

}
