<?php

namespace App\Http\Controllers;

use App\Models\PC;
use Exception;
use App\Models\Test;
use App\Models\Doctor;
use App\Models\Invoice;
use App\Models\Patient;
use Illuminate\Http\Request;
use App\Helper\ResponseHelper;
use App\Models\InvoiceDetails;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class InvoiceController extends Controller
{

    public function index(){
        $InvoicePageData = Invoice::latest()->first();
        return ResponseHelper::Out('success', $InvoicePageData, 200);
    }

    public function InvoiceByID(Request $request){
        try {
            $user_id = Auth::id();
            $request->validate(["id" => 'required|string']);

            $rows = Invoice::where('id', $request->input('id'))->where('user_id', $user_id)->first();
            return response()->json(['status' => 'success', 'rows' => $rows]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


    public function PataientData()
    {
        try {
            // Fetch the latest patient data
            $patientData = Patient::latest()->first();

            // If no patient data is found, return an error response
            if (!$patientData) {
                return ResponseHelper::Out('error', 'Patient data not found', 404);
            }

            // Fetch the doctor's name based on the patient's doctor_id
            $doctorName = '';
            if ($patientData->doctor_id) {
                $doctor = Doctor::find($patientData->doctor_id);
                if ($doctor) {
                    $doctorName = $doctor->name;
                }
            }

            // Include the doctor's name in the response data
            $responseData = $patientData->toArray();
            $responseData['doctor_name'] = $doctorName;

            // Return success response with patient data including doctor's name
            return ResponseHelper::Out('success', $responseData, 200);
        } catch (Exception $e) {
            // Handle any exceptions
            return ResponseHelper::Out('error', $e->getMessage(), 500);
        }
    }





//    public function InvoiceDetailsData()
//    {
//        try {
//            // Get the most recent invoice ID
//            $latestInvoiceId = InvoiceDetails::orderBy('created_at', 'desc')->value('invoice_id');
//
//            // If no invoice details are found, return an empty response or handle it as per your requirement
//            if (!$latestInvoiceId) {
//                return response()->json(['error' => 'No invoice details found']);
//            }
//
//            // Get all corresponding test ids for the most recent invoice id
//            $testIds = InvoiceDetails::where('invoice_id', $latestInvoiceId)->pluck('test_id');
//
//            // Retrieve the test names for the most recent invoice id
//            $testNames = Test::whereIn('id', $testIds)->pluck('test_name')->toArray();
//
//            // Ensure testNames is always an array
//            if (!is_array($testNames)) {
//                $testNames = [$testNames]; // Convert to array if not already
//            }
//
//            // Return the test names for the most recent invoice id
//            return response()->json(['invoice_details' => $testNames]);
//        } catch (Exception $e) {
//            // Handle any exceptions
//            return response()->json(['error' => $e->getMessage()]);
//        }
//    }



    public function InvoicePrintReceipt()
    {
        try {
            // Get the most recent invoice details
            $latestInvoiceDetails = InvoiceDetails::orderBy('created_at', 'desc')->first();

            // If no invoice details are found, return an empty response or handle it as per your requirement
            if (!$latestInvoiceDetails) {
                return response()->json(['error' => 'No invoice details found']);
            }

            // Retrieve associated invoice and patient information
            $invoiceId = $latestInvoiceDetails->invoice_id;
            $invoice = Invoice::with('patient')->find($invoiceId);

            // Retrieve all corresponding test details for the specific invoice id
            $testDetails = InvoiceDetails::where('invoice_id', $invoiceId)
                ->with('test:id,test_name,price') // Eager load the test details with only required fields
                ->get();

            // Prepare the response data including invoice details, patient information, and test details
            $responseData = [
                'id' => $invoiceId,
                'invoice_reg' => $invoice->invoice_reg,
                'payment_status' => $invoice->payment_status,
                'subtotal' => $invoice->subtotal,
                'discount_amount' => $invoice->discount_amount,
                'payment_method' => $invoice->payment_method,
                'paid_amount' => $invoice->paid_amount,
                'due_amount' => $invoice->due_amount,
                'doctor_name' => $this->getDoctorName($invoice->doctor_id),
                'report_delivery_time' => $invoice->report_delivery_time,
                'report_delivery_date' => $invoice->report_delivery_date,

                'patient' => [
                    'id' => $invoice->patient->id,
                    'patient_name' => $invoice->patient->patient_name,
                    'age' => $invoice->patient->age,
                    'gender' => $invoice->patient->gender,
                    'mobile' => $invoice->patient->mobile,
                    'address' => $invoice->patient->address
                    // Add more patient fields as needed
                ],

                'invoice_details' => $testDetails->map(function ($detail) {
                    return [
                        'test_name' => $detail->test->test_name,
                        'price' => $detail->test->price
                    ];
                })->toArray()
            ];

            // Return the response containing all required data
            return response()->json($responseData);
        } catch (Exception $e) {
            // Handle any exceptions
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    // Helper method to get doctor's name by doctor_id
    private function getDoctorName($doctorId)
    {
        $doctor = Doctor::find($doctorId);
        return $doctor ? $doctor->name : null;
    }

    function InvoiceReportList(Request $request)
    {
        try {
            $user_id = Auth::id();
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');

            // Query to fetch invoice data within the specified date range for the authenticated user
            $invoices = Invoice::whereBetween('invoice_date', [$startDate, $endDate])
                ->get();

            return response()->json(['status' => 'success', 'Invoice_Report_Data' => $invoices]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    public function AllInvoiceReportList(){
        try {
            $user_id = Auth::id();
            $invoice_data = Invoice::get();
            return response()->json(['status' => 'success', 'invoice_data' => $invoice_data]);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    public function GetInvoicesByPatient($patient_id){
        try {
            $patient = Patient::findOrFail($patient_id); // Assuming you have a Patient model
            $invoices = Invoice::where('patient_id', $patient_id)->get();

            return response()->json([
                'success' => true,
                'patient' => $patient,
                'invoices' => $invoices
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while fetching invoices by patient.'
            ], 500);
        }
    }

    public function GetInvoicesByPC($pc_id){
        try {
            $pc = PC::findOrFail($pc_id);
            $invoices = Invoice::where('pc_id', $pc_id)->get();

            return response()->json([
                'success' => true,
                'pc' => $pc,
                'invoices' => $invoices
            ], 200);
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while fetching invoices by patient.'
            ], 500);
        }
    }


    public function CreateInvoice(Request $request)
    {
        try {
            // Create patient
            $patient = Patient::create([
                'patient_name' => $request->input('patient_name'),
                'mobile' => $request->input('mobile'),
                'gender' => $request->input('gender'),
                'age' => $request->input('age'),
                'dob' => $request->input('dob'),
                'blood_group' => $request->input('blood_group'),
                'address' => $request->input('address'),
                'email' => $request->input('email'),
                'user_id' => Auth::id()
            ]);

            // Create invoice
            $invoice = Invoice::create([
                'invoice_reg' => $this->generateInvoiceNumber(),
                'pc_discount' => $request->input('pc_discount'),
                'referred_by_doctor' => $request->input('referred_by_doctor'),
                'pc_reference_name' => $request->input('pc_reference_name'),
                'doctor_id' => $request->input('doctor_id'),
                'subtotal' => $request->input('subtotal'),
                'invoice_date' => $request->input('invoice_date'),
                'report_delivery_date' => $request->input('report_delivery_date'),
                'report_delivery_time' => $request->input('report_delivery_time'),
                'discount_ap' => $request->input('discount_ap'),
                'discount_amount' => $request->input('discount_amount'),
                'payment_status' => $request->input('payment_status'),
                'payment_method' => $request->input('payment_method'),
                'paid_amount' => $request->input('paid_amount'),
                'due_amount' => $request->input('due_amount'),
                'pc_id' => $request->input('pc_id'),
                'patient_id' => $patient->id,
                'user_id' => Auth::id()
            ]);

            // Create invoice details
            $tests = json_decode($request->input('tests'), true);

            foreach ($tests as $test) {
                InvoiceDetails::create([
                    'invoice_id' => $invoice->id,
                    'test_id' => $test['test_id'],
                    'user_id' => Auth::id()
                ]);
            }

            // Redirect to the oldPatientsPage after successful invoice creation
            return response()->json(['status' => 'success', 'message' => 'Invoice created successfully']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }

    public function CreateOldPatientInvoice(Request $request){
        try {

            // Create invoice
            $invoice = Invoice::create([
                'invoice_reg' => $this->generateInvoiceNumber(),
                'pc_discount' => $request->input('pc_discount'),
                'referred_by_doctor' => $request->input('referred_by_doctor'),
                'pc_reference_name' => $request->input('pc_reference_name'),
                'doctor_id' => $request->input('doctor_id'),
                'subtotal' => $request->input('subtotal'),
                'invoice_date' => $request->input('invoice_date'),
                'report_delivery_date' => $request->input('report_delivery_date'),
                'report_delivery_time' => $request->input('report_delivery_time'),
                'discount_ap' => $request->input('discount_ap'),
                'discount_amount' => $request->input('discount_amount'),
                'payment_status' => $request->input('payment_status'),
                'payment_method' => $request->input('payment_method'),
                'paid_amount' => $request->input('paid_amount'),
                'due_amount' => $request->input('due_amount'),
                'pc_id' => $request->input('pc_id'),
                'patient_id' => $request->input('SearchBar'),
                'user_id' => Auth::id()
            ]);

            // Create invoice details
            $tests = json_decode($request->input('tests'), true);

            foreach ($tests as $test) {
                InvoiceDetails::create([
                    'invoice_id' => $invoice->id,
                    'test_id' => $test['test_id'],
                    'user_id' => Auth::id()
                ]);
            }

            // Redirect to the oldPatientsPage after successful invoice creation
            return response()->json(['status' => 'success', 'message' => 'Invoice created successfully']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


// Helper method to generate invoice number
    private function generateInvoiceNumber()
    {
        $lastInvoice = Invoice::orderBy('id', 'desc')->first();
        $lastInvoiceId = $lastInvoice ? (int)substr($lastInvoice->invoice_reg, -4) : 0;
        $newInvoiceId = $lastInvoiceId + 1;
        return '#MDC_INV_' . str_pad($newInvoiceId, 4, '0', STR_PAD_LEFT);
    }

    public function AllDueInvoiceReportList(){
        try {
            // Retrieve all due invoices where due_amount > 0
            $invoices = Invoice::where('due_amount', '>', 0)->get();

            return response()->json([
                'success' => true,
                'invoice_data' => $invoices
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while fetching due invoices.'
            ], 500);
        }
    }

    public function PayDue(Request $request)
    {

        try {
            // Find the invoice by ID
            $invoice = Invoice::findOrFail($request->input('id'));

            // Update the due amount
            $invoice->due_amount =$invoice->due_amount - $request->input('due_amount');

            // Calculate the paid amount based on the subtotal and updated due amount
            $invoice->paid_amount = $invoice->paid_amount + $request->input('due_amount');

            // Save the changes
            $invoice->save();

            // Return success response
            return response()->json([
                'status' => 'success',
                'message' => 'Pay Due Data Update Successful'
            ]);
        } catch (Exception $e) {
            // Return error response if an exception occurs
            return response()->json([
                'status' => 'fail',
                'message' => $e->getMessage()
            ]);
        }

    }


    function DeleteInvoice(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|string|min:1'
            ]);
            $Invoice_id = $request->input('id');
            $Invoice_Delete = Invoice::find($Invoice_id);

            if (!$Invoice_Delete) {
                return response()->json(['status' => 'fail', 'message' => 'Invoice Is not found.']);
            }
            Invoice::where('id', $Invoice_id)->delete();

            return response()->json(['status' => 'success', 'message' => 'Invoice Delete Successful']);
        } catch (Exception $e) {
            return response()->json(['status' => 'fail', 'message' => $e->getMessage()]);
        }
    }


}
