<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use App\Models\Expenses;
use App\Models\Invoice;
use App\Models\Patient;
use App\Models\PC;
use App\Models\Test;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class DashboardController extends Controller
{
    public function DashboardAllCalculation(){
        try {
            $monthlyTotalPaidAmount = Invoice::whereYear('created_at', '=', date('Y'))
                ->whereMonth('created_at', '=', date('m'))
                ->sum('paid_amount');
            $monthlyTotalExpenseAmount = Expenses::whereYear('created_at', '=', date('Y'))
                ->whereMonth('created_at', '=', date('m'))
                ->sum('amount');
            $monthlyTotalBalanceAmount = $monthlyTotalPaidAmount - $monthlyTotalExpenseAmount;

            $todayTotalPaidAmount = Invoice::whereDate('created_at', Carbon::today())->sum('paid_amount');

            $todayTotalExpensesAmount = Expenses::whereDate('created_at', Carbon::today())->sum('amount');

            $todayTotalBalanceAmount = $todayTotalPaidAmount - $todayTotalExpensesAmount;

//            $totalDueAmount = Invoice::sum('due_amount');
//            $totalPCDiscountAmount = Invoice::sum('pc_discount');
//            $totalExpensesAmount = Expenses::sum('amount');
//            $todaySellAmount = Invoice::whereDate('created_at', Carbon::today())->sum('subtotal');
//            $todayTotalPaidAmount = Invoice::whereDate('created_at', Carbon::today())->sum('paid_amount');
//            $todayPCDiscountAmount = Invoice::whereDate('created_at', Carbon::today())->sum('pc_discount');
//            $todayTotalDueAmount = Invoice::whereDate('created_at', Carbon::today())->sum('due_amount');
//            $todayTotalExpensesAmount = Expenses::whereDate('created_at', Carbon::today())->sum('amount');
//            $totalPatient= Patient::count('id');
//            $totalDoctor= Doctor::count('id');
//            $totalPC= PC::count('id');
//            $totalTest= Test::count('id');

            return response()->json([
                'monthlyTotalPaidAmount' => $monthlyTotalPaidAmount,
                'monthlyTotalExpenseAmount' => $monthlyTotalExpenseAmount,
                'monthlyTotalBalanceAmount' => $monthlyTotalBalanceAmount,
                'todayTotalPaidAmount' => $todayTotalPaidAmount,
                'todayTotalExpensesAmount' => $todayTotalExpensesAmount,
                'todayTotalBalanceAmount' => $todayTotalBalanceAmount,
            ]);
        } catch (Exception $e) {
            return response()->json(['error' => 'Unable to fetch total values.']);
        }
    }
}
