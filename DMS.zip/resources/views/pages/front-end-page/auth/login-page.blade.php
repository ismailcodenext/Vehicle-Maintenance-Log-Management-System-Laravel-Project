@extends('layout.app')
@section('title','Login Page')
@section('content')
    @include('components.front-end.auth.login-form')
@endsection

