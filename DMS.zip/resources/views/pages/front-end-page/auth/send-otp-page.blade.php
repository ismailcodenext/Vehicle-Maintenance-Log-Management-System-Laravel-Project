@extends('layout.app')
@section('content')
    @include('components.front-end.auth.send-otp-form')
@endsection


