@extends('layout.app')
@section('content')
    @include('components.front-end.auth.verify-otp-form')
@endsection
