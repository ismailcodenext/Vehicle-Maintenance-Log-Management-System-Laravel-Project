@extends('layout.sidenav-layout')
@section('content')
    @include('components.dashboard.profile-form')
@endsection

