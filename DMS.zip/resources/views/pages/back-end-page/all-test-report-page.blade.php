@extends('layout.sidenav-layout')
@section('title','Invoice Report')
@section('content')
    @include('components.back-end.test.all-test-report')
@endsection




