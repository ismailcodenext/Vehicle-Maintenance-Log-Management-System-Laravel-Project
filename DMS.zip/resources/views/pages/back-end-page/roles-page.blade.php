@extends('layout.sidenav-layout')
@section('title','Categorie')
@section('content')
    @include('components.back-end.roles.roles-list')
    @include('components.back-end.roles.roles-create')
    {{--    @include('components.back-end.test-categorie.test-categorie-update')--}}
    {{--    @include('components.back-end.test-categorie.test-categorie-delete')--}}
@endsection
