@extends('layout.sidenav-layout')
@section('title','Expenses Categorie')
@section('content')
    @include('components.back-end.expenses-categorie.expenses-categorie-list')
    @include('components.back-end.expenses-categorie.expenses-categorie-create')
    @include('components.back-end.expenses-categorie.expenses-categorie-update')
    @include('components.back-end.expenses-categorie.expenses-categorie-delete')
@endsection
