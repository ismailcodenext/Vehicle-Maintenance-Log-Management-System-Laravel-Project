@extends('layout.sidenav-layout')
@section('title','Expenses')
@section('content')
    @include('components.back-end.expenses.expenses-list')
    @include('components.back-end.expenses.expenses-create')
    @include('components.back-end.expenses.expenses-update')
    @include('components.back-end.expenses.expenses-delete')
@endsection
