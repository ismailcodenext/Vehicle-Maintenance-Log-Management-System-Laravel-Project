@extends('layout.sidenav-layout')
@section('title','Dashboard')
@section('content')
    @include('components.back-end.dasboardsummary')
@endsection
