@extends('layout.sidenav-layout')
@section('title','Patient')
@section('content')
    @include('components.back-end.patient.patient-list')
    @include('components.back-end.patient.patient-create')
    @include('components.back-end.patient.patient-update')
    @include('components.back-end.patient.patient-delete')
@endsection
