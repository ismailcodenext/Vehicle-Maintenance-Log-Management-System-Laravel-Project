@extends('layout.sidenav-layout')
@section('title','Categorie')
@section('content')
    @include('components.back-end.test-categorie.test-categorie-list')
    @include('components.back-end.test-categorie.test-categorie-create')
    @include('components.back-end.test-categorie.test-categorie-update')
    @include('components.back-end.test-categorie.test-categorie-delete')
@endsection
