@extends('layout.sidenav-layout')
@section('title','Invoice Report')
@section('content')
    @include('components.back-end.invoice-report.date-wise-invoice-report')
    {{-- @include('components.back-end.invoice-report.report-create')
    @include('components.back-end.invoice-report.report-update')
    @include('components.back-end.invoice-report.report-delete') --}}
@endsection
