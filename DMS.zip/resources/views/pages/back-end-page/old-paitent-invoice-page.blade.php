@extends('layout.sidenav-layout')
@section('title','Old Paitent Invoice')
@section('content')
    @include('components.back-end.old-invoice.old-invoice-create')
@endsection
