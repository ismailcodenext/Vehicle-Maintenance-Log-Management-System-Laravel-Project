@extends('layout.sidenav-layout')
@section('title','Doctor')
@section('content')
    @include('components.back-end.doctor.doctor-list')
    @include('components.back-end.doctor.doctor-create')
    @include('components.back-end.doctor.doctor-update')
    @include('components.back-end.doctor.doctor-delete')

@endsection
