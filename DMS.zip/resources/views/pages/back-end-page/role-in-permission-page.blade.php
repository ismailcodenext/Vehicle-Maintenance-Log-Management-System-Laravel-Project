@extends('layout.sidenav-layout')
@section('title','Role-In-Permission')
@section('content')
{{--    @include('components.back-end.role-in-permission.role-in-permission-list')--}}
    @include('components.back-end.role-in-permission.role-in-permission-create')
    {{--    @include('components.back-end.test-categorie.test-categorie-update')--}}
    {{--    @include('components.back-end.test-categorie.test-categorie-delete')--}}
@endsection
