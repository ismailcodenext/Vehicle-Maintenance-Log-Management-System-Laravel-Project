@extends('layout.sidenav-layout')
@section('title','Invoice Report')
@section('content')
    @include('components.back-end.invoice-report.patient-wise-invoice-report')
@endsection
