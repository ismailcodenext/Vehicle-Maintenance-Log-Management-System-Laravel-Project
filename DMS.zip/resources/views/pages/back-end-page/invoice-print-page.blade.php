@extends('layout.sidenav-layout')
@section('title','Invoice')
@section('content')
    @include('components.back-end.invoice-print.invoice-print')
@endsection
