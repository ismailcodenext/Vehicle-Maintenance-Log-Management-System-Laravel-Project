@extends('layout.sidenav-layout')
@section('title','Invoice')
@section('content')
    @include('components.back-end.invoice.invoice-create')
@endsection
