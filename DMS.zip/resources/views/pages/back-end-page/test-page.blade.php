@extends('layout.sidenav-layout')
@section('title', 'Medical Test')
@section('content')
    @include('components.back-end.test.test-page-list')
    @include('components.back-end.test.test-page-create')
    @include('components.back-end.test.test-page-update')
    @include('components.back-end.test.test-page-delete')

@endsection
