@extends('layout.sidenav-layout')
@section('title','Invoice Report')
@section('content')
    @include('components.back-end.invoice-report.all-due-invoice-report')
    @include('components.back-end.invoice-report.pay-due-invoice')
@endsection
