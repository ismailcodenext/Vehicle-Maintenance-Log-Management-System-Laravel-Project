@extends('layout.sidenav-layout')
@section('title','PC')
@section('content')
    @include('components.back-end.pc.pc-list')
    @include('components.back-end.pc.pc-create')
    @include('components.back-end.pc.pc-update')
    @include('components.back-end.pc.pc-delete')
@endsection
