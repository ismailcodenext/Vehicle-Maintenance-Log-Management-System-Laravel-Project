<div class="modal animated zoomIn" style="z-index: 99999999 !important;" id="update-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Doctor Page</h5>
            </div>
            <div class="modal-body">
                <form id="update-form">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-md-6">
                                    <label class="form-label">email *</label>
                                <input type="text" class="form-control test_form_input" id="UpdateDoctorEmail">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Chamber Address *</label>
                                <input type="text" class="form-control test_form_input" id="UpdateChamberAddress">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Name *</label>
                                <input type="text" class="form-control test_form_input" id="UpdateDoctorName">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Specialization*</label>
                                <input type="text" class="form-control test_form_input" id="UpdateDoctorspecialization">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Degree *</label>
                                <input type="text" class="form-control test_form_input" id="UpdateDoctorDegree">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Hospital *</label>
                                <input type="text" class="form-control test_form_input" id="UpdateDoctorHospital">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">mobile *</label>
                                <input type="text" class="form-control test_form_input" id="UpdateDoctorMobile">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">registration_number *</label>
                                <input type="text" class="form-control test_form_input" id="UpdateDoctorRegistrationNumber">
                                    </div>

                                    <div class="col-md-6">
                                        <div class="d-flex align-items-center mt-3">
                                            <img class="w-25 me-3" id="oldImg" src="{{ asset('images/default.jpg') }}"/>
                                            <div>
                                                <label class="form-label">Photo</label>
                                                <input oninput="updatePreview(this)" type="file" class="form-control" id="UpdateDoctorImage">
                                                <input class="d-none" id="updateID">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button id="update-modal-close" class="btn modal_close_btn" data-bs-dismiss="modal" aria-label="Close">Close</button>
                <button onclick="Update(event)" id="update-btn" class="btn modal_update_btn" >Update</button>
            </div>
        </div>
    </div>
</div>

<script>
async function updatePreview(input, imageUrl) {
    const oldImg = document.getElementById('oldImg');

    if (input.files && input.files[0]) {
        oldImg.src = window.URL.createObjectURL(input.files[0]);
    } else if (imageUrl) {
        oldImg.src = imageUrl;
    } else {
        oldImg.src = "{{ asset('images/default.jpg') }}";
    }
}


async function FillUpUpdateForm(id) {
    try {
        document.getElementById('updateID').value = id;
        showLoader();
        let res = await axios.post("/doctor-by-id", { id: id.toString() }, HeaderToken());
        hideLoader();

        let data = res.data.rows;
        document.getElementById('UpdateDoctorEmail').value = data.email;
        document.getElementById('UpdateChamberAddress').value = data.chamber_address;
        document.getElementById('UpdateDoctorName').value = data.name;
        document.getElementById('UpdateDoctorspecialization').value = data.specialization;
        document.getElementById('UpdateDoctorDegree').value = data.degree;
        document.getElementById('UpdateDoctorHospital').value = data.hospital;
        document.getElementById('UpdateDoctorMobile').value = data.mobile;
        document.getElementById('UpdateDoctorRegistrationNumber').value = data.registration_number;

        // Update the preview with the existing image URL
        updatePreview(document.getElementById('UpdateDoctorImage'), data.img_url);
    } catch (e) {
        unauthorized(e.response.status);
    }
}


    async function Update() {
        try {
            let UpdateDoctorEmail = document.getElementById('UpdateDoctorEmail').value;
            let UpdateChamberAddress = document.getElementById('UpdateChamberAddress').value;
            let UpdateDoctorName = document.getElementById('UpdateDoctorName').value;
            let UpdateDoctorspecialization = document.getElementById('UpdateDoctorspecialization').value;
            let UpdateDoctorDegree = document.getElementById('UpdateDoctorDegree').value;
            let UpdateDoctorHospital = document.getElementById('UpdateDoctorHospital').value;
            let UpdateDoctorMobile = document.getElementById('UpdateDoctorMobile').value;
            let UpdateDoctorRegistrationNumber = document.getElementById('UpdateDoctorRegistrationNumber').value;
            let updateID = document.getElementById('updateID').value;
            let UpdateDoctorImage = document.getElementById('UpdateDoctorImage').files[0];

            // if (!CastNameUpdate || !CasttitleUpdate || !CastViewLinkUpdate || !updateID) {
            //     errorToast("All fields are required!");
            //     return;
            // }

            document.getElementById('update-modal-close').click();

            let formData = new FormData();
            formData.append('email', UpdateDoctorEmail);
            formData.append('chamber_address', UpdateChamberAddress);
            formData.append('name', UpdateDoctorName);
            formData.append('specialization', UpdateDoctorspecialization);
            formData.append('degree', UpdateDoctorDegree);
            formData.append('hospital', UpdateDoctorHospital);
            formData.append('mobile', UpdateDoctorMobile);
            formData.append('registration_number', UpdateDoctorRegistrationNumber);
            formData.append('img', UpdateDoctorImage);
            formData.append('id', updateID);

            const config = {
                headers: {
                    'content-type': 'multipart/form-data',
                    ...HeaderToken().headers
                }
            };

            showLoader();

            let res = await axios.post("/update-Doctor", formData, config);
            hideLoader();

            if (res.data.status === "success") {
                successToast(res.data.message);
                let modal = new bootstrap.Modal(document.getElementById('update-modal'));
            modal.hide();
                await getList();
            } else {
                errorToast(res.data.message);
            }

        } catch (e) {
            unauthorized(e.response.status);
        }
    }
</script>
