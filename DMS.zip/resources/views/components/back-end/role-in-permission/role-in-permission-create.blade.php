<div class="container" style="padding-top: 20px;">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-lg-12">
            <div class="wrapper">

                <div class="row justify-content-between ">
                    <div class="align-items-center col">
                        <h4>Role In Permission Create</h4>
                    </div>
                    <div class="align-items-center col">
                        <button data-bs-toggle="modal" data-bs-target="#create-modal" class="float-end create_btn">Create</button>

                    </div>
                </div>

                <hr class="bg-dark "/>



            </div>

        </div>
    </div>
</div>


