<div class="modal animated zoomIn" style="z-index: 99999999 !important;" id="update-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Permission</h5>
            </div>
            <div class="modal-body">
                <form id="update-form">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label class="form-label"> Permission Name</label>
                                    <input type="text" class="form-control" id="PermissionNameUpdate">
                                    <input class="d-none" id="updateID">  >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="firstname" class="form-label">Group Name </label>
                                    <select name="group_name" id="PermissionGroupNameUpdate" class="form-select" id="example-select">
                                        <option selected disabled >Select Group  </option>
                                        <option value="doctor">Doctor</option>
                                        <option value="pc">PC</option>
                                        <option value="patient">Patient</option>
                                        <option value="expense">Expense</option>
                                        <option value="test">Test</option>
                                        <option value="invoice">Invoice</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button id="update-modal-close" class="btn bg-gradient-primary" data-bs-dismiss="modal" aria-label="Close">Close</button>
                <button onclick="Update(event)" id="update-btn" class="btn bg-gradient-success" >Update</button>
            </div>
        </div>
    </div>
</div>

<script>
    async function FillUpUpdateForm(id) {
        try {
            document.getElementById('updateID').value = id;
            showLoader();
            let res = await axios.post("/permission-by-id", { id: id.toString() }, HeaderToken());
            hideLoader();

            let data = res.data.rows;
            document.getElementById('PermissionNameUpdate').value = data.name;
            document.getElementById('PermissionGroupNameUpdate').value = data.group_name;
        } catch (e) {
            unauthorized(e.response.status);
        }
    }


    async function Update() {
        try {
            let PermissionNameUpdate = document.getElementById('PermissionNameUpdate').value;
            let PermissionGroupNameUpdate = document.getElementById('PermissionGroupNameUpdate').value;
            let updateID = document.getElementById('updateID').value;

            document.getElementById('update-modal-close').click();

            let formData = new FormData();
            formData.append('name', PermissionNameUpdate);
            formData.append('group_name', PermissionGroupNameUpdate);
            formData.append('id', updateID);

            const config = {
                headers: {
                    'content-type': 'multipart/form-data',
                    ...HeaderToken().headers
                }
            };

            showLoader();

            let res = await axios.post("/update-permission", formData, config);
            hideLoader();

            if (res.data.status === "success") {
                successToast(res.data.message);
                let modal = new bootstrap.Modal(document.getElementById('update-modal'));
                modal.hide();
                await getList();
            } else {
                errorToast(res.data.message);
            }

        } catch (e) {
            unauthorized(e.response.status);
        }
    }
</script>
