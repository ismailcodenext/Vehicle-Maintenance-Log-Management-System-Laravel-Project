<!-- Patient Creation Modal -->
<div class="modal animated zoomIn" style="z-index: 99999999 !important;" id="create-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title" id="exampleModalLabel">Permission Create</h6>
            </div>
            <div class="modal-body">
                <form id="save-form">
                    <div class="container" style="padding: 0 10px">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="firstname" class="form-label">Permission Name</label>
                                    <input type="text" id="PermissionName" name="name" class="form-control"   >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="firstname" class="form-label">Group Name </label>
                                    <select name="group_name" id="GroupName" class="form-select" id="example-select">
                                        <option selected disabled >Select Group  </option>
                                        <option value="doctor">Doctor</option>
                                        <option value="pc">PC</option>
                                        <option value="patient">Patient</option>
                                        <option value="expense">Expense</option>
                                        <option value="test">Test</option>
                                        <option value="invoice">Invoice</option>
                                    </select>
                                </div>
                            </div>
                        </div> <!-- end row -->
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button id="modal-close" class="btn modal_close_btn" data-bs-dismiss="modal" aria-label="Close">Close</button>
                <button onclick="Save()" id="save-btn" class="btn" style="width: auto;">Save</button>
            </div>
        </div>
    </div>
</div>

<script>
    async function Save() {
        try {
            let PermissionName = document.getElementById('PermissionName').value;
            let GroupName = document.getElementById('GroupName').value;

            if (PermissionName.length === 0) {
                errorToast("Cast Name Required !");
            } else if (GroupName.length === 0) {
                errorToast("Cast Title Required !");
            }
            else {
                document.getElementById('modal-close').click();
                let formData = new FormData();
                formData.append('name',PermissionName );
                formData.append('group_name',GroupName);

                const config = {
                    headers: {
                        'content-type': 'multipart/form-data',
                        ...HeaderToken().headers
                    }
                }

                let res = await axios.post("/create-permission", formData, config);


                if (res.data['status'] === "success") {
                    successToast(res.data['message']);
                    document.getElementById("save-form").reset();
                    await getList();
                } else {
                    errorToast(res.data['message'])
                }
            }

        } catch (e) {
            unauthorized(e.response.status)
        }
    }
</script>
