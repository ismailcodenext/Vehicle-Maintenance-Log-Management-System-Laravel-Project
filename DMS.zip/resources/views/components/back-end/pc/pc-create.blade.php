<!-- Patient Creation Modal -->
<div class="modal animated zoomIn" style="z-index: 99999999 !important;" id="create-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">PC Create</h5>
            </div>
            <div class="modal-body">
                <form id="save-form">
                    <div class="container" style="padding: 0 10px">
                        <div class="row">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="form-label">PC Name *</label>
                                        <input type="text" class="form-control test_form_input" id="PCName">
                                    </div>

                                    <div class="col-md-6">
                                        <label class="form-label">Mobile *</label>
                                        <input type="number" class="form-control test_form_input" id="PCMobile">
                                    </div>

                                    <div class="col-md-6">
                                        <label class="form-label">Email *</label>
                                        <input type="email" class="form-control test_form_input" id="PCEmail">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">NID Number *</label>
                                <input type="text" class="form-control test_form_input" id="PCNIDNumber">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Address *</label>
                                <input type="text" class="form-control test_form_input" id="Address">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Age *</label>
                                <input type="number" class="form-control test_form_input" id="Age">
                                    </div>

                                    <div class="col-md-6">

                                    <label class="form-label">Gender *</label>
                                <select class="form-select" id="Gender" aria-label="Default select example">
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Status *</label>
                                <select class="form-select" id="Status" aria-label="Default select example" >
                                    <option value="">Select Status</option>
                                    <option value="Active">Active</option>
                                    <option value="Unactive">Unactive</option>
                                </select>
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Hospital *</label>
                                <input type="text" class="form-control test_form_input" id="Hospital" >
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Discount Percentage *</label>
                                <input type="number" class="form-control test_form_input" id="DiscountPercentage" >
                                    </div>

                                    <div class="col-md-6">
                                        <div class="d-flex align-items-center mt-3">
                                            <img style="width: 100px; margin-right: 10px;" id="newImg" src="{{ asset('images/default.jpg') }}" />
                                            <div>
                                                <label class="form-label">Photo</label>
                                                <input oninput="newImg.src=window.URL.createObjectURL(this.files[0])" type="file"
                                                class="form-control pc_img_input" id="PCImage">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button id="modal-close" class="btn modal_close_btn" data-bs-dismiss="modal" aria-label="Close">Close</button>
                <button onclick="Save()" id="save-btn" class="btn" style="width: auto;">Save</button>
            </div>
        </div>
    </div>
</div>

<script>
    async function Save() {
        try {
            let PCName = document.getElementById('PCName').value;
            let PCMobile = document.getElementById('PCMobile').value;
            let PCEmail = document.getElementById('PCEmail').value;
            let PCNIDNumber = document.getElementById('PCNIDNumber').value;
            let Address = document.getElementById('Address').value;
            let Gender = document.getElementById('Gender').value;
            let Age = document.getElementById('Age').value;
            let Status = document.getElementById('Status').value;
            let Hospital = document.getElementById('Hospital').value;
            let DiscountPercentage = document.getElementById('DiscountPercentage').value;

            let imgInput = document.getElementById('PCImage');
            let imgFile = imgInput.files[0];


            if (PCName.length === 0) {
                errorToast("PC Name Required !");
            }

            else if (PCMobile.length === 0) {
                errorToast("PC Mobile Required !");
            }

            else if (PCEmail.length === 0) {
                errorToast("PC Email Required !");
            }

            else if (PCNIDNumber.length === 0) {
                errorToast("PC NID Number Required !");
            }

            else if (Address.length === 0) {
                errorToast("PC Address Required !");
            }

            else if (Age.length === 0) {
                errorToast("PC Age Required !");
            }

            else if (Gender.length === 0) {
                errorToast("PC Gender Required !");
            }

            else if (Status.length === 0) {
                errorToast("PC Status Required !");
            }

            else if (Hospital.length === 0) {
                errorToast("PC Hospital Required !");
            }

            else if (DiscountPercentage.length === 0) {
                errorToast("PC Discount Percentage Required !");
            }

            else if (!imgInput.files || imgInput.files.length === 0) {
                errorToast("Doctor Photo Required !");
                return;
            }
        else {

            document.getElementById('modal-close').click();
            let formData = new FormData();
            formData.append('name', PCName);
            formData.append('mobile', PCMobile);
            formData.append('email', PCEmail);
            formData.append('nid', PCNIDNumber);
            formData.append('address', Address);
            formData.append('gender', Gender);
            formData.append('age', Age);
            formData.append('img', imgFile);
            formData.append('status', Status);
            formData.append('hospital', Hospital);
            formData.append('discount_percentage', DiscountPercentage);

            showLoader();
            let res = await axios.post("/create-pc", formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    ...HeaderToken().headers
                }
            });
            hideLoader();

            if (res.data.status === "success") {
                successToast(res.data.message);
                document.getElementById("save-form").reset();
                await getList();
            } else {
                errorToast(res.data.message);
            }
            }
        } catch (error) {
            unauthorized(error.response.status);
        }
    }
</script>
