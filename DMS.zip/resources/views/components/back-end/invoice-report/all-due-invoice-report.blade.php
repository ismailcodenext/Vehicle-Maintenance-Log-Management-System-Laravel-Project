<div class="container-fluid" style="padding-top: 20px">
    <div class="wrapper">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="row justify-content-between">
                    <div class="align-items-center col">
                        <h4>All Due Invoice Report List</h4>
                    </div>
                </div>

                <hr style="margin: 20px 0; color: #332941;"/>

                <div class="table-responsive">
                    <table class="table invoice_table" id="tableData">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>Invoice Reg</th>
                            <th>Invoice Date</th>
                            <th>Subtotal</th>
                            <th>Discount</th>
                            <th>Paid Amount</th>
                            <th>Due Amount</th>
                            <th>Patient ID</th>
                            <th>PC ID</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody id="tableList"></tbody>
                        <tfoot>
                        <tr id="totalCounts">
                            <th colspan="3">Total</th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                        </tfoot>
                    </table>
                </div>

            </div>
        </div>
    </div>

</div>

<script>
    getList()
    async function getList() {
        try {
            let res = await axios.get("/all-due-invoice-report", HeaderToken());
            let tableList = $("#tableList");
            let tableData = $("#tableData");

            showLoader();
            tableData.DataTable().destroy();
            tableList.empty();
            hideLoader();

            res.data['invoice_data'].forEach(function (item, index) {
                let row = `<tr>
                    <td>${index + 1}</td>
                    <td>${item['invoice_reg']}</td>
                    <td>${item['invoice_date']}</td>
                    <td>${item['subtotal']}</td>
                    <td>${item['discount_amount']}</td>
                    <td>${item['paid_amount']}</td>
                    <td>${item['due_amount']}</td>
                    <td>${item['patient_id']}</td>
                    <td>${item['pc_id']}</td>
                    <td>
                        <div style="display: flex;">
                            <button title="Pay Due" data-id="${item['id']}" class="button moneyBtn"><i class="fa-solid fa-money-bill"></i>
                            </button>
                            </div>
                    </td>
                 </tr>`;
                tableList.append(row);
            });

            // Calculate totals
            let subtotalTotal = 0;
            let discountTotal = 0;
            let paidAmountTotal = 0;
            let dueAmountTotal = 0;

            res.data['invoice_data'].forEach(function (item, index) {
                subtotalTotal += parseFloat(item['subtotal']);
                discountTotal += parseFloat(item['discount_amount']);
                paidAmountTotal += parseFloat(item['paid_amount']);
                dueAmountTotal += parseFloat(item['due_amount']);
            });

            // Append totals to the footer
            let totalCountsRow = `
                <tr id="totalCounts">
                    <th colspan="3">Total</th>
                    <th>${subtotalTotal.toFixed(2)}</th>
                    <th>${discountTotal.toFixed(2)}</th>
                    <th>${paidAmountTotal.toFixed(2)}</th>
                    <th>${dueAmountTotal.toFixed(2)}</th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>`;
            $('#tableData tfoot').empty().append(totalCountsRow); // Append to table footer

            $('.moneyBtn').on('click', async function () {
                let id = $(this).data('id');
                await FillUpUpdateForm(id);
                $("#pay-due").modal('show');
            });

            $('.editBtn').on('click', async function () {
                let id = $(this).data('id');
                await FillUpUpdateForm(id);
                $("#update-modal").modal('show');
            });


            $('.deleteBtn').on('click', function () {
                let id = $(this).data('id');
                $("#delete-modal").modal('show');
                $("#deleteID").val(id);
            });

            new DataTable('#tableData', {
                layout: {
                    topStart: {
                        buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
                    }
                }
            });

        } catch (e) {
            unauthorized(e.response.status)
        }
    };



</script>
