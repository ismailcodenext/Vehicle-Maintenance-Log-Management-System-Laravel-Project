<div class="container-fluid" style="padding-top: 20px">
    <div class="wrapper">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
                    <div class="row justify-content-between">
                        <div class="col-12">
                            <h4 class="text-center">Date Wise Invoice Report List</h4>
                        </div>
                        <div class="col-12">
                            <div class="row">
                                <div class="col-md-4">
                                    <label>Start Date:</label>
                                    <input type="text" class="form-control test_form_input" id="startDate">
                                </div>

                                <div class="col-md-4">
                                    <label>End Date:</label>
                                    <input type="text" class="form-control test_form_input" id="endDate">
                                </div>

                                <div class="col-md-4">
                                    <button class="btn search_btn" id="searchBtn">Search</button>
                                </div>

                            </div>
                        </div>
                    </div>

                    <hr style="margin: 20px 0; color: #332941;"/>

                    <div class="table-responsive">
                        <table class="table invoice_table" id="tableData">
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Invoice Reg</th>
                                <th>Invoice Date</th>
                                <th>PC Reference Name</th>
                                <th>Subtotal</th>
                                <th>Discount</th>
                                <th>Paid Amount</th>
                                <th>Due Amount</th>
                                <th>PC Commission</th>
                                <th>Patient ID</th>
                                <th>PC ID</th>

                            </tr>
                            </thead>
                            <tbody id="tableList"></tbody>
                            <tfoot>
                            <tr id="totalCounts">
                                <th colspan="3">Total</th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>

            </div>
        </div>
    </div>

</div>

<script>
    $(document).ready(function() {
        $('#searchBtn').on('click', function () {
            let startDate = $('#startDate').val();
            let endDate = $('#endDate').val();
            getList(startDate, endDate);
        });

        async function getList(startDate, endDate) {
            try {
                showLoader();
                let res = await axios.get("/invoice-report", {
                    ...HeaderToken(),
                    params: {
                        start_date: startDate,
                        end_date: endDate
                    }
                });
                hideLoader();

                let tableList = $("#tableList");
                let tableData = $("#tableData");

                tableData.DataTable().destroy();
                tableList.empty();

                res.data['Invoice_Report_Data'].forEach(function (item, index) {
                    let row = `<tr>
                    <td>${index + 1}</td>
                    <td>${item['invoice_reg']}</td>
                    <td>${item['invoice_date']}</td>
                    <td>${item['pc_reference_name']}</td>
                    <td>${item['subtotal']}</td>
                    <td>${item['discount_amount']}</td>
                    <td>${item['paid_amount']}</td>
                    <td>${item['due_amount']}</td>
                    <td>${item['pc_discount']}</td>
                    <td>${item['patient_id']}</td>
                    <td>${item['pc_id']}</td>
                 </tr>`;
                    tableList.append(row);
                });

                // Calculate totals
                let subtotalTotal = 0;
                let discountTotal = 0;
                let paidAmountTotal = 0;
                let dueAmountTotal = 0;
                let pcDiscountAmountTotal = 0;

                res.data['Invoice_Report_Data'].forEach(function (item, index) {
                    subtotalTotal += parseFloat(item['subtotal']);
                    discountTotal += parseFloat(item['discount_amount']);
                    paidAmountTotal += parseFloat(item['paid_amount']);
                    dueAmountTotal += parseFloat(item['due_amount']);
                    pcDiscountAmountTotal += parseFloat(item['pc_discount']);
                });

                // Append totals to the footer
                let totalCountsRow = `
                <tr id="totalCounts">
                    <th colspan="4">Total</th>
                    <th>${subtotalTotal.toFixed(2)}</th>
                    <th>${discountTotal.toFixed(2)}</th>
                    <th>${paidAmountTotal.toFixed(2)}</th>
                    <th>${dueAmountTotal.toFixed(2)}</th>
                    <th>${pcDiscountAmountTotal.toFixed(2)}</th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>`;
                $('#tableData tfoot').empty().append(totalCountsRow); // Append to table footer

                $('.editBtn').on('click', async function () {
                    let id = $(this).data('id');
                    await FillUpUpdateForm(id);
                    $("#update-modal").modal('show');
                });

                $('.deleteBtn').on('click', function () {
                    let id = $(this).data('id');
                    $("#delete-modal").modal('show');
                    $("#deleteID").val(id);
                });

                new DataTable('#tableData', {
                    layout: {
                        topStart: {
                            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
                        }
                    }
                });

            } catch (e) {
                unauthorized(e.response.status)
            }
        }
    });




    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("startDate");
        flatpickr(inputField, {
            dateFormat: "Y-m-d",
            defaultDate: "today",
            onClose: function(selectedDates, dateStr, instance) {
                inputField.value = dateStr;
            }
        });
    });


    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("endDate");
        flatpickr(inputField, {
            dateFormat: "Y-m-d",
            defaultDate: "today",
            onClose: function(selectedDates, dateStr, instance) {
                inputField.value = dateStr;
            }
        });
    });

</script>

