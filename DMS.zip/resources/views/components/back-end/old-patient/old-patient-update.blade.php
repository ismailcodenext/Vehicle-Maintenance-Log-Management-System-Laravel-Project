<div class="modal animated zoomIn" id="update-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog old-paitent-model modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Patient Information</h5>
            </div>
            <div class="modal-body">
                <form id="update-form">
                    <div class="container">
                        <div class="card text-center" style="width: 800px; margin: 50px auto ;">
                            <form id="test-form">
                                <div class="card-body">
                                    <h5 class="card-title">Add Test</h5>

                                    <select class="form-select" id="TestList" aria-label="Default select example">
                                        <option value="">Select Test</option>
                                    </select>

                                    <div class="form-row">
                                        <div class="col">
                                            <label class="form-label">ID</label>
                                            <input type="text" class="form-control" id="testID">

                                        </div>
                                        <div class="col">
                                            <label class="form-label">Price</label>
                                            <input type="text" class="form-control" id="price">

                                        </div>
                                        <div class="col">
                                            <label class="form-label">Referrer Fee</label>
                                            <input type="text" class="form-control" id="referrer-fee">
                                        </div>
                                    </div>

                                    <button type="button" onclick="addTest()" class="btn btn-primary mt-3">Add
                                        Test</button>
                                </div>
                            </form>

                        </div>
                        <div class="container">
                            <div class="row justify-content-center mt-5">
                                <div class="col-6">
                                    <h2 class="text-uppercase text-end">Patient Information</h2>
                                </div>
                            </div>
                            <form id="save-form">
                                <div class="row">
                                    <div class="col-md-4 p-1">
                                        <label class="form-label">Patient Name *</label>
                                        <input type="text" class="form-control" id="UpdatePatientName">
                                        <label class="form-label">Mobile *</label>
                                        <input type="text" class="form-control" id="UpdateMobile">
                                        <label class="form-label">Gender *</label>
                                        <input type="text" class="form-control"  id="UpdateGender">
                                        <label class="form-label">Age *</label>
                                        <input type="text" class="form-control" id="UpdateAge">
                                    </div>
                                    <div class="col-md-4 p-1">
                                        <label class="form-label">Date Of Birth *</label>
                                        <input type="date" class="form-control" id="UpdateDateOfBirth">
                                        <label class="form-label">Blood Group *</label>
                                        <input type="text" class="form-control" id="UpdateBloodGroup">
                                        <label class="form-label">Address *</label>
                                        <input type="text" class="form-control" id="UpdateAddress">
                                        <label class="form-label">Email *</label>
                                        <input type="email" class="form-control" id="UpdateEmail">
                                    </div>
                                    <div class="col-md-4 p-1">
                                        <label class="form-label">Doctor *</label>
                                        <input type="text" class="form-control"  id="UpdateDoctorID">
                                        <label class="form-label">Referred By *</label>
                                        <input type="text" class="form-control"  id="UpdateReferredByID">
                                        {{-- <label class="form-label">PC ID *</label>
                                        <select class="form-select" id="PCByID" aria-label="Default select example">
                                            <option value="">Select PC</option>
                                        </select> --}}
                                    </div>
                                </div>
                                {{-- Invoice Section --}}
                                <div class="row d-flex justify-content-between mt-5">
                                    <div class="col-6">
                                        <h2 class="text-uppercase text-end">Invoice</h2>
                                    </div>
                                    <div class="col-6 text-end">
                                        <p>Invoice Date: <input type="date" readonly class="bg-danger"
                                                id="InvoiceDate"></p>
                                        <p>Report Delivery Date: <input type="date" id="reportDeliveryDate"></p>
                                        <p>Time: <input type="time" id="reportDeliveryTime"></p>
                                    </div>
                                </div>
                                <hr>


                                <div class="row">
                                    <div class="col-12">
                                        <h4>Test Name</h4>
                                    </div>
                                </div>
                                <div class="row">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>SL</th>
                                                <th>Test ID</th>
                                                <th>Test Name</th>
                                                <th>Amount</th>
                                            </tr>
                                        </thead>


                                        <tbody id="testTableBody">
                                            <!-- Add an id to tbody for easy manipulation -->
                                        </tbody>
                                        <tfoot>

                                            <tr>
                                                <td colspan="2" class="text-end">Sub Total:</td>
                                                <td><span id="subTotal">0.00</span></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" class="text-end">Discount?:</td>
                                                <td>
                                                    <select class="form-select" id="discountSelect">
                                                        <option value="Amount">Amount</option>
                                                        <option value="Percentage">Percentage</option>
                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" class="text-end">Discount:</td>
                                                <td><input type="number" id="discount" class="form-control"
                                                        value="0"></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" class="text-end">Discount Amount:</td>
                                                <td><span id="discountAmount">0</span></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" class="text-end">Payment Status:</td>
                                                <td>
                                                    <select class="form-select" id="PaymentStatus">
                                                        <option value="Full Paid">Full Paid</option>
                                                        <option value="Due">Due</option>
                                                        <option value="Partial Paid">Partial Paid</option>
                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" class="text-end">Payment Method:</td>
                                                <td>
                                                    <select class="form-select" id="PaymentMethod">
                                                        <option value="Cash">Cash</option>
                                                        <option value="Bikash">Bikash</option>
                                                        <option value="Nagad">Nagad</option>
                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" class="text-end">Payment:</td>
                                                <td><input type="number" id="PaidAmount" class="form-control"
                                                        value="0"></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" class="text-end">Due Amount:</td>
                                                <td><span id="dueAmount">0.00</span></td>
                                            </tr>
                                        </tfoot>
                                        <input type="hidden" value="Active" id="InvoiceStatus">
                                    </table>
                                </div>
                                <input class="d-none" id="updateID">
                            </form>
                            <hr>
                            <div class="row text-end">
                                <div class="col-10">
                                    <button onclick="Save()" id="save-btn"
                                        class="btn bg-gradient-success">Submit</button>
                                </div>
                            </div>
                        </div>

                    </div>
            </div>

        </div>

        </form>
    </div>
</div>


<script>
    async function FillUpUpdateForm(id) {
    try {
        document.getElementById('updateID').value = id;
        showLoader();
        let res = await axios.post("/patient-by-id", { id: id.toString() }, HeaderToken());
        hideLoader();

        let data = res.data.rows;
        document.getElementById('UpdatePatientName').value = data.patient_name;
        document.getElementById('UpdateMobile').value = data.mobile;
        document.getElementById('UpdateGender').value = data.gender;
        document.getElementById('UpdateAge').value = data.age;
        document.getElementById('UpdateDateOfBirth').value = data.dob;
        document.getElementById('UpdateBloodGroup').value = data.blood_group;
        document.getElementById('UpdateAddress').value = data.address;
        document.getElementById('UpdateEmail').value = data.email;
        document.getElementById('UpdateDoctorID').value = data.doctor_id;
        document.getElementById('UpdateReferredByID').value = data.referred_by_id;
    } catch (e) {
        unauthorized(e.response.status);
    }
}
</script>