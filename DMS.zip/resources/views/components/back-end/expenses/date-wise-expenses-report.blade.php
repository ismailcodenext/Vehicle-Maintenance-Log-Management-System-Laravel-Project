<div class="container-fluid" style="padding-top: 20px">
    <div class="wrapper">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">

            <div class="row justify-content-between">
                        <div class="col-12">
                            <h4 class="text-center">Date Wise Expenses Report</h4>
                        </div>
                        <div class="col-12">
                            <div class="row">
                                <div class="col-md-4">
                                    <label>Start Date:</label>
                                    <input type="date" class="form-control test_form_input" id="startDate">
                                </div>

                                <div class="col-md-4">
                                    <label>End Date:</label>
                                    <input type="date" class="form-control test_form_input" id="endDate">
                                </div>

                                <div class="col-md-4">
                                    <button class="btn search_btn" id="searchBtn">Search</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- <div class="row justify-content-between">
                        <div class="align-items-center col">
                            <h4>Date Wise Expenses Report</h4>
                        </div>
                        <div class="col-auto">
                            <div class="input-group">
                                <input type="date" class="form-control" id="startDate">
                                <span class="input-group-text">to</span>
                                <input type="date" class="form-control" id="endDate">
                                <button class="btn btn-primary" id="searchBtn">Search</button>
                            </div>
                        </div>
                    </div> -->



                    <hr style="margin: 20px 0; color: #332941;"/>

                    <div class="table-responsive">
                        <table class="table invoice_table" id="tableData">
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Expenses Name</th>
                                <th>Expenses Details</th>
                                <th>Amount</th>
                                <th>Date</th>
                            </tr>
                            </thead>
                            <tbody id="tableList"></tbody>
                            <tfoot>
                            <tr id="totalRow">
                                <th colspan="3">Total</th>
                                <th id="totalAmount"></th>
                                <th></th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>

            </div>
        </div>
    </div>

</div>

<script>
    $(document).ready(function () {
        let tableData = null;

        $('#searchBtn').on('click', function () {
            let startDate = $('#startDate').val();
            let endDate = $('#endDate').val();
            getList(startDate, endDate);
        });

        async function getList(startDate, endDate) {
            try {
                showLoader();
                let res = await axios.get("/date-wise-expenses", {
                    ...HeaderToken(),
                    params: {
                        start_date: startDate,
                        end_date: endDate
                    }
                });
                hideLoader();

                let tableList = $("#tableList");
                tableData = $("#tableData");

                tableData.DataTable().destroy();
                tableList.empty();

                let totalAmount = 0;
                res.data['Expenses_Report_Data'].forEach(function (item, index) {
                    let row = `<tr>
                    <td>${index + 1}</td>
                    <td>${item['name']}</td>
                    <td>${item['expense_note']}</td>
                    <td>${item['amount']}</td>
                    <td>${item['date']}</td>
                 </tr>`;
                    tableList.append(row);
                });

                tableData.DataTable({
                    layout: {
                        topStart: {
                            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
                        }
                    }
                });

                // Update total amount
                updateTotalAmount();

                // Listen for search event
                tableData.on('search.dt', function () {
                    updateTotalAmount();
                });

            } catch (e) {
                unauthorized(e.response.status)
            }
        }

        function updateTotalAmount() {
            let api = tableData.DataTable().rows({ search: 'applied' }).data();
            let totalAmount = 0;
            api.each(function (value) {
                totalAmount += parseFloat(value[3]); // Assuming amount is in the 4th column (index 3)
            });
            $('#totalAmount').text(totalAmount.toFixed(2));
        }
    });


    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("startDate");
        flatpickr(inputField, {
            dateFormat: "Y-m-d",
            defaultDate: "today",
            onClose: function(selectedDates, dateStr, instance) {
                inputField.value = dateStr;
            }
        });
    });


    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("endDate");
        flatpickr(inputField, {
            dateFormat: "Y-m-d",
            defaultDate: "today",
            onClose: function(selectedDates, dateStr, instance) {
                inputField.value = dateStr;
            }
        });
    });

</script>


