



<div id="printable-content">
    <div class="print-btn">
        <button onclick="printInvoice()" class="print_btn">Print</button>
    </div>
<div class="wrapper_invoice">
    <header id="invoiceheading">
        <div class="hospital-logo">
            <img src="{{asset('images/logo.jpg')}}" />
            <div>
            <h3>Modern Diagnostic Home</h3>
            <p>Address: Dr. Ishaque Mansion, Dr. Ishaque Lane, Gopalpur, Pabna</p>
            <p>Email: mdhpabna@gmail.com</p>
            <p>Phone: 02-588845606, Mobile: 01711-142185</p>
        </div>
        </div>
        <h3 style="text-align: center;margin-bottom:40px; font-size: 1.2em; display: inline-block; border-bottom: 2px solid #000;">Invoice/Cash Memo</h3>
        <div class="devider"></div>
    </header>
    <div class="invoice_details">
        <div class="invoice_detail left">
            <p><strong>Invoice ID:</strong> <span id="InvoiceID"></span></p>
            <p><strong>Invoice Reg:</strong> <span id="InvoiceReg"></span></p>
            <p><strong>Patient ID:</strong> <span id="PatientID"></span></p>
            <p><strong>Patient Name:</strong> <span id="PatientName"></span></p>
            <p><strong>Patient Age:</strong> <span id="PatientAge"></span></p>
            <p><strong>Dr.Name:</strong> <span id="DoctorName"></span></p>

        </div>
        <div class="invoice_detail right">
            <p><strong>Inv Time:</strong> <span id="InvTime"></span></p>
            <p><strong>Inv Date:</strong> <span id="InvDate"></span></p>
            <p><strong>Patient Address:</strong> <span id="PatientAddress"></span></p>
            <p><strong>Patient Sex:</strong> <span id="patient-sex"></span></p>
            <p><strong>Patient Phone:</strong> <span id="PatientPhone"></span></p>
        </div>
    </div>

    <section class="table-container mt-3">
        <table class="invoice-print-table">
            <thead>
            <tr>
                <th style="font-weight: bold !important;">SL</th>
                <th style="font-weight: bold !important;">Name of Test</th>
                <!-- <th>Delivery Date</th> -->
                <th style="font-weight: bold !important;">Amount</th>
            </tr>
            </thead>
            <tbody style="text-align: center;" id="testNamesBody">

            </tbody>

            <tr>
                <th rowspan="6" style="text-align:center !important; font-size:30px;" id="PaymentStatus"></th>
            </tr>
            <tr>
                <th style="text-align: right !important;">Total Amount</th>
                <td id="SubTotal" style="width: 170px !important"></td>
            </tr>
            <tr>
                <th style="text-align: right !important;">Discount Amount:</th>
                <td id="DiscountAmount"></td>
            </tr>
            <tr>
                <th style="text-align: right !important;">Payment Method:</th>
                <td id="PaymentMethod"></td>
            </tr>
            <tr>
                <th style="text-align: right !important;">Payment</th>
                <td id="PaymentAmount"></td>
            </tr>

            <tr>
                <th style="text-align: right !important;">Due Payment</th>
                <td id="DueAmount"></td>
            </tr>
        </table>
    </section>
    <div class="branding-test">
        <p style="text-align: center;  ">Develop By CodeNext IT - www.codenextit.com | +880 1788428280</p>
    </div>

</div>
</div>


<script>
    function printInvoice() {
        // Hide the print button before printing
        document.querySelector('.print-btn').style.display = 'none';

        // Print the content inside the #printable-content div
        const printableContent = document.getElementById('printable-content').innerHTML;
        const originalContent = document.body.innerHTML;
        document.body.innerHTML = printableContent;

        // Print the content
        window.print();

        // Restore original content
        document.body.innerHTML = originalContent;

        // Show the print button after printing
        document.querySelector('.print-btn').style.display = 'block';
    }
</script>

<style>
    @media print {
        body {
            margin: 0;
            padding: 0;
            line-height: 1.4;
            color: #000;
            background: #fff;
            font-family: "Outfit", sans-serif;
            font-size: 12px;
        }
        #printable-content {
            width: 100%;
            margin: 0 auto;
            padding: 20px;
            box-shadow: none;
        }
        .hospital-logo {
            margin-bottom: 10px;
        }
        .hospital-logo img {
            width: 30px;
            height: 30px;
        }
        .hospital-logo h3 {
            font-size: 1.4em;
            margin-bottom: 0;
        }
        .hospital-logo p {
            font-size: 12px;
            line-height: 14px;
            margin-bottom: 0;
        }
        .invoice-print-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .invoice-print-table th, .invoice-print-table td {
            border: 1px solid #070505;
            padding: 5px 8px;
            text-align: left;
        }
        .invoice-print-table th {
            font-weight: bold;
            text-align: right;
        }
        .branding-test p {
            text-align: center;
            font-size: 9px;
            margin-top: 10px;
        }
        .print-btn {
            display: none;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        fetchInvoiceDetails();
    });

    async function fetchInvoiceDetails() {
        try {
            const response = await axios.get("/invoice_print_receipt");
            console.log("Response from API:", response.data);

            if (response.data && !response.data.hasOwnProperty('error')) {
                const invoiceData = response.data;

                // Display invoice ID and other details
                document.getElementById('InvoiceID').innerText = invoiceData.id;
                document.getElementById('InvoiceReg').innerText = invoiceData.invoice_reg;
                document.getElementById('PatientID').innerText = invoiceData.patient.id;
                document.getElementById('PatientName').innerText = invoiceData.patient.patient_name;
                document.getElementById('PatientAge').innerText = invoiceData.patient.age;
                document.getElementById('DoctorName').innerText = invoiceData.doctor_name;
                document.getElementById('InvTime').innerText = invoiceData.report_delivery_time;
                document.getElementById('InvDate').innerText = invoiceData.report_delivery_date;
                document.getElementById('PatientAddress').innerText = invoiceData.patient.address;
                document.getElementById('patient-sex').innerText = invoiceData.patient.gender;
                document.getElementById('PatientPhone').innerText = invoiceData.patient.mobile;

                // Display test details
                const testDetails = invoiceData.invoice_details;
                const testNamesBody = document.getElementById('testNamesBody');
                let serialNumber = 1;

                testDetails.forEach(testDetail => {
                    const testName = testDetail.test_name;
                    const price = testDetail.price;

                    const row = `
                        <tr>
                            <td>${serialNumber++}</td>
                            <td>${testName}</td>
                            <td>${price}</td>
                        </tr>
                    `;
                    testNamesBody.insertAdjacentHTML('beforeend', row);
                });

                // Display payment details
                document.getElementById('PaymentStatus').innerText = invoiceData.payment_status;
                document.getElementById('SubTotal').innerText = invoiceData.subtotal;
                document.getElementById('DiscountAmount').innerText = invoiceData.discount_amount;
                document.getElementById('PaymentMethod').innerText = invoiceData.payment_method;
                document.getElementById('PaymentAmount').innerText = invoiceData.paid_amount;
                document.getElementById('DueAmount').innerText = invoiceData.due_amount;
            } else {
                console.warn("No invoice details found");
            }
        } catch (error) {
            console.error("Error fetching invoice details:", error);
        }
    }
</script>
