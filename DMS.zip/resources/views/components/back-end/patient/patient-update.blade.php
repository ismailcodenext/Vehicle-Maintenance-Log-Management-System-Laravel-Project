<div class="modal animated zoomIn" style="z-index: 99999999 !important;" id="update-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Patient Information</h5>
            </div>
            <div class="modal-body">
                <form id="update-form">
                    <div class="container" style="padding: 0 10px">
                        <div class="row">
                            <div class="col-12 p-1">
                                <div class="row">
                                    <div class="col-md-6">
                                    <label class="form-label">Patient Name *</label>
                                <input type="text" class="form-control test_form_input" id="UpdatePatientName">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Mobile *</label>
                                <input type="text" class="form-control test_form_input" id="UpdateMobile">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Gender *</label>
                                <input type="text" class="form-control test_form_input" readonly id="UpdateGender">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Age *</label>
                                <input type="text" class="form-control test_form_input" id="UpdateAge">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Date Of Birth *</label>
                                <input type="date" class="form-control test_form_input" id="UpdateDateOfBirth">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Blood Group *</label>
                                <input type="text" class="form-control test_form_input" id="UpdateBloodGroup">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Address *</label>
                                <input type="text" class="form-control test_form_input" id="UpdateAddress">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Email *</label>
                                <input type="email" class="form-control test_form_input" id="UpdateEmail">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Doctor *</label>
                                <input type="text" class="form-control test_form_input" readonly id="UpdateDoctorID">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Referred By *</label>
                                <input type="text" class="form-control test_form_input" readonly id="UpdateReferredByID">
                                <input class="d-none" id="updateID">
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button id="update-modal-close" class="btn modal_close_btn" data-bs-dismiss="modal" aria-label="Close">Close</button>
                <button onclick="Update(event)" id="update-btn" class="btn modal_update_btn" style="width: auto;">Update</button>
            </div>
        </div>
    </div>
</div>

<script>

async function FillUpUpdateForm(id) {
    try {
        document.getElementById('updateID').value = id;
        showLoader();
        let res = await axios.post("/patient-by-id", { id: id.toString() }, HeaderToken());
        hideLoader();

        let data = res.data.rows;
        document.getElementById('UpdatePatientName').value = data.patient_name;
        document.getElementById('UpdateMobile').value = data.mobile;
        document.getElementById('UpdateGender').value = data.gender;
        document.getElementById('UpdateAge').value = data.age;
        document.getElementById('UpdateDateOfBirth').value = data.dob;
        document.getElementById('UpdateBloodGroup').value = data.blood_group;
        document.getElementById('UpdateAddress').value = data.address;
        document.getElementById('UpdateEmail').value = data.email;
        document.getElementById('UpdateDoctorID').value = data.doctor_id;
        document.getElementById('UpdateReferredByID').value = data.referred_by_id;
    } catch (e) {
        unauthorized(e.response.status);
    }
}


    async function Update() {
        try {
            let UpdatePatientName = document.getElementById('UpdatePatientName').value;
            let UpdateMobile = document.getElementById('UpdateMobile').value;
            let UpdateGender = document.getElementById('UpdateGender').value;
            let UpdateAge = document.getElementById('UpdateAge').value;
            let UpdateDateOfBirth = document.getElementById('UpdateDateOfBirth').value;
            let UpdateBloodGroup = document.getElementById('UpdateBloodGroup').value;
            let UpdateAddress = document.getElementById('UpdateAddress').value;
            let UpdateEmail = document.getElementById('UpdateEmail').value;
            let UpdateDoctorID = document.getElementById('UpdateDoctorID').value;
            let UpdateReferredByID = document.getElementById('UpdateReferredByID').value;
            let updateID = document.getElementById('updateID').value;

            document.getElementById('update-modal-close').click();

            let formData = new FormData();
                formData.append('patient_name', UpdatePatientName);
                formData.append('mobile', UpdateMobile);
                formData.append('gender', UpdateGender);
                formData.append('age', UpdateAge);
                formData.append('dob', UpdateDateOfBirth);
                formData.append('blood_group', UpdateBloodGroup);
                formData.append('address', UpdateAddress);
                formData.append('email', UpdateEmail);
                formData.append('doctor_id', UpdateDoctorID);
                formData.append('referred_by_id', UpdateReferredByID);
                formData.append('id', updateID);

            const config = {
                headers: {
                    'content-type': 'multipart/form-data',
                    ...HeaderToken().headers
                }
            };

            showLoader();

            let res = await axios.post("/update-patient", formData, config);
            hideLoader();

            if (res.data.status === "success") {
                successToast(res.data.message);
                let modal = new bootstrap.Modal(document.getElementById('update-modal'));
            modal.hide();
                await getList();
            } else {
                errorToast(res.data.message);
            }

        } catch (e) {
            unauthorized(e.response.status);
        }
    }
</script>
