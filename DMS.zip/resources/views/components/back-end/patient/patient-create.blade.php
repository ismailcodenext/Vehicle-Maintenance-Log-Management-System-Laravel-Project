<!-- Patient Creation Modal -->
<div class="modal animated zoomIn" style="z-index: 99999999 !important;" id="create-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title" id="exampleModalLabel">Patient Create</h6>
            </div>
            <div class="modal-body">
                <form id="save-form">
                    <div class="container" style="padding: 0 10px">
                        <div class="row">
                            <div class="col-12 p-1">
                                <div class="row">
                                    <div class="col-md-6">
                                    <label class="form-label">Patient Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control test_form_input" id="PatientName">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Mobile <span class="text-danger">*</span></label>
                                <input type="text" class="form-control test_form_input" id="Mobile">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Gender <span class="text-danger">*</span></label>
                                <select class="form-select" id="Gender" aria-label="Default select example">
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Age <span class="text-danger">*</span></label>
                                <input type="text" class="form-control test_form_input" id="Age">
                                    </div>

                                    <div class="col-md-6">
                                        <label class="form-label">Date Of Birth <span class="text-danger">*</span></label>
                                        <input type="date" class="form-control test_form_input" id="DateOfBirth">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Blood Group <span class="text-danger">*</span></label>
                                <input type="text" class="form-control test_form_input" id="BloodGroup">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Address <span class="text-danger">*</span></label>
                                <input type="text" class="form-control test_form_input" id="Address">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Email <span class="text-danger">*</span></label>
                                <input type="email" class="form-control test_form_input" id="Email">
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Doctor <span class="text-danger">*</span></label>
                                <select class="form-select" id="DoctorID" aria-label="Default select example">
                                    <option value="">Select Doctor</option>
                                </select>
                                    </div>

                                    <div class="col-md-6">
                                    <label class="form-label">Referred By <span class="text-danger">*</span></label>
                                <select class="form-select" id="ReferredByID" aria-label="Default select example">
                                    <option value="">Select Referrer</option>
                                </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button id="modal-close" class="btn modal_close_btn" data-bs-dismiss="modal" aria-label="Close">Close</button>
                <button onclick="Save()" id="save-btn" class="btn" style="width: auto;">Save</button>
            </div>
        </div>
    </div>
</div>

<script>
    FillDropDowns();

    async function FillDropDowns() {
        try {
            let res = await axios.get("/list-doctor", HeaderToken());
            let doctors = res.data.doctor_data;
            let referrals = res.data.doctor_data;

            let optionsHtmlDoctors = doctors.map(doctor => `<option value="${doctor.id}">${doctor.name}</option>`).join('');
            $("#DoctorID").html(optionsHtmlDoctors);

            let optionsHtmlReferrals = referrals.map(referral => `<option value="${referral.id}">${referral.name}</option>`).join('');
            $("#ReferredByID").html(optionsHtmlReferrals);
        } catch (error) {
            console.error("Error occurred while fetching doctors and referrals:", error);
        }
    }

    async function Save() {
        try {
            let patientName = document.getElementById('PatientName').value;
            let mobile = document.getElementById('Mobile').value;
            let gender = document.getElementById('Gender').value;
            let age = document.getElementById('Age').value;
            let dob = document.getElementById('DateOfBirth').value;
            let bloodGroup = document.getElementById('BloodGroup').value;
            let address = document.getElementById('Address').value;
            let email = document.getElementById('Email').value;
            let doctorId = document.getElementById('DoctorID').value;
            let referredById = document.getElementById('ReferredByID').value;


            if (patientName.length === 0) {
                errorToast("Patient Name Required !");
            } else if (mobile.length === 0) {
                errorToast("Patient Mobile Required !");
            }
            else if (gender.length === 0) {
                errorToast("Patient Gender Required !");
            }

            else if (age.length === 0) {
                errorToast("Patient Age Required !");
            }

            else if (dob.length === 0) {
                errorToast("Patient Date Of Birth Required !");
            }

            else if (address.length === 0) {
                errorToast("Patient Address Required !");
            }else
            {

            document.getElementById('modal-close').click();
            let formData = new FormData();
            formData.append('patient_name', patientName);
            formData.append('mobile', mobile);
            formData.append('gender', gender);
            formData.append('age', age);
            formData.append('dob', dob);
            formData.append('blood_group', bloodGroup);
            formData.append('address', address);
            formData.append('email', email);
            formData.append('doctor_id', doctorId);
            formData.append('referred_by_id', referredById);

            const config = {
                headers: {
                    'content-type': 'multipart/form-data',
                    ...HeaderToken().headers
                }
            };

            showLoader();
            let res = await axios.post("/create-patient", formData, config);
            hideLoader();

            if (res.data.status === "success") {
                successToast(res.data.message);
                document.getElementById("save-form").reset();
                await getList();
            } else {
                errorToast(res.data.message);
            }
        }
        } catch (error) {
            unauthorized(error.response.status);
        }
    }

    document.addEventListener("DOMContentLoaded", function() {
        const inputField = document.getElementById("DateOfBirth");
        flatpickr(inputField, {
            dateFormat: "Y-m-d",
            defaultDate: "today",
            onClose: function(selectedDates, dateStr, instance) {
                inputField.value = dateStr;
            }
        });
    });

</script>


