<div class="container-fluid">
    <div class="row">

        <div class="col-12">
            <h1>Welcome to Our Dashboard!</h1>
            <p>We're glad to have you here. Enjoy exploring our content and services.</p>
        </div>
    </div>
</div>




{{--<script>--}}
{{--    getList();--}}
{{--    async function getList() {--}}
{{--        showLoader();--}}
{{--        let res=await axios.get("/summary");--}}

{{--        document.getElementById('product').innerText=res.data['product']--}}
{{--        document.getElementById('category').innerText=res.data['category']--}}
{{--        document.getElementById('customer').innerText=res.data['customer']--}}
{{--        document.getElementById('invoice').innerText=res.data['invoice']--}}
{{--        document.getElementById('total').innerText=res.data['total']--}}
{{--        document.getElementById('vat').innerText=res.data['vat']--}}
{{--        document.getElementById('payable').innerText=res.data['payable']--}}


{{--        hideLoader();--}}
{{--    }--}}
{{--</script>--}}
